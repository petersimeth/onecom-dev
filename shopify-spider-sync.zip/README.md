# Shopify Store Spider

A small, polite, resumable web spider that discovers external domains from seed
pages, checks them for Shopify signals, and exports confirmed stores to CSV.

The MVP uses only the Python standard library. It does not bypass access
controls, log in, crawl checkout/customer areas, or scrape search-engine result
pages.

## What it does

- Crawls public seed pages to a bounded depth.
- Extracts external domains as Shopify candidates.
- Scores several independent Shopify storefront signals.
- Crawls a small set of permitted public pages on confirmed stores.
- Saves its frontier and results in SQLite so interrupted runs can resume.
- Exports store metadata, evidence, public emails, and social links to CSV.
- Honors `robots.txt` by default and rate-limits requests per host.
- Runs an async worker pool with a live progress bar for faster bounded crawls.
- Includes an interactive menu for common scan, status, export, and seed tasks.
- Batches SQLite queue, discovery, and page-completion writes to reduce crawl overhead.
- Finds bounded candidate storefronts through the latest Common Crawl URL index.
- Writes structured rotating logs for diagnostics and unattended runs.
- Detects a bounded set of public app signatures and JSON-LD product records.
- Securely syncs stores, apps, products, and change signals to ShopSignal.

## Quick start

Python 3.11 or newer is required.

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -e .
cp examples/seeds.txt seeds.txt
shopify-spider scan seeds.txt --output stores.csv
```

Or discover candidate Shopify storefronts without preparing a seed file:

```bash
shopify-spider discover --limit 500 --scan --output stores.csv
```

You can also open the interactive menu:

```bash
shopify-spider menu
```

Running `shopify-spider` with no subcommand opens the same menu.

Without installing the package, run it directly from the repository:

```bash
PYTHONPATH=src python3 -m shopify_spider scan examples/seeds.txt \
  --database shopify_spider.sqlite3 \
  --output stores.csv
```

Use a descriptive user agent with contact information for substantial crawls:

```bash
shopify-spider scan seeds.txt \
  --user-agent "MyResearchBot/0.1 (+mailto:you@example.com)" \
  --delay 2 \
  --max-pages 1000
```

## Commands

```bash
# Crawl or resume a crawl
shopify-spider scan seeds.txt

# Discover candidates from Common Crawl and add them to the queue
shopify-spider discover --limit 500

# Discover and immediately validate candidates
shopify-spider discover --limit 500 --scan

# Keep an operational log while scanning
shopify-spider discover --limit 500 --scan --log-file logs/spider.log

# Open the interactive menu
shopify-spider menu

# Inspect progress
shopify-spider status --database shopify_spider.sqlite3

# Re-export without crawling
shopify-spider export --database shopify_spider.sqlite3 --output stores.csv

# Preview how many changed stores are ready to sync
shopify-spider sync --database shopify_spider.sqlite3 --dry-run
```

Important scan options:

| Option | Default | Meaning |
| --- | ---: | --- |
| `--max-pages` | 250 | Total pages processed in this run |
| `--max-domains` | 500 | Maximum candidate domains discovered |
| `--depth` | 2 | Internal-link depth on discovery sites |
| `--store-depth` | 1 | Internal-link depth on confirmed stores |
| `--pages-per-host` | 8 | Hard page cap for each host |
| `--concurrency` | 4 | Async worker count |
| `--delay` | 1.0 | Minimum seconds between requests to one host |
| `--no-progress` | false | Disable the live progress bar |

`--ignore-robots` exists only for controlled local testing. Do not use it for
third-party sites unless you have explicit authorization.

## Logging

Every command supports optional rotating file logs:

```bash
shopify-spider scan seeds.txt --log-file logs/spider.log
shopify-spider scan seeds.txt --log-file logs/spider.log --log-level DEBUG
```

Logs include command and crawl lifecycle events, candidate discovery, detected
stores, robots decisions, fetch failures, queue activity, and exports. Log files
rotate at 5 MB and keep three backups. Warnings are shown on the terminal by
default; add `--verbose` to mirror the selected log level to the terminal.
Verbose mode disables the progress bar so log lines remain readable.

## Common Crawl discovery

`discover` queries the latest Common Crawl URL index for archived
`*.myshopify.com` storefront URLs, converts them to unique HTTPS homepages, and
adds them to the resumable SQLite queue. It does not download archived page
contents. Use `--scan` to validate the candidates immediately with the normal
Shopify detector.

The query is deliberately bounded to at most 5,000 candidates per invocation
because the public index is shared and rate-limited. You can pin a crawl with
`--collection CC-MAIN-YYYY-WW` or supply another bounded URL pattern with
`--query`. Duplicate candidates are ignored by SQLite.

## Interactive menu

The menu is useful when you do not want to remember flags. It can:

- Discover and optionally validate Common Crawl candidates.
- Start or resume a scan.
- Show current crawl status.
- Export confirmed stores to CSV.
- Append seed URLs/domains to a seed file.

The scanner remains scriptable, so the menu is optional.

## Async crawling and progress

The spider uses an `asyncio` worker pool to keep multiple crawl tasks moving at
once while still enforcing per-host delay and `robots.txt` checks. Because the
MVP intentionally stays standard-library-only, HTTP requests are performed with
Python's built-in URL client in background worker threads instead of requiring an
external async HTTP package.

Crawler state is stored in SQLite with batched queue/dequeue operations and
single-transaction page completion, so high-link pages do not create one commit
per discovered URL.

During scans, the CLI shows a live progress bar with processed page count,
confirmed store count, pending queue count, failed page count, and the current
URL. Use `--no-progress` when running in logs or other non-interactive contexts.

## Detection model

The detector combines evidence such as:

- Shopify generator markup
- `Shopify.shop`, `Shopify.theme`, and related JavaScript globals
- `/cdn/shop/` and `cdn.shopify.com` assets
- `*.myshopify.com` references
- Shopify section/analytics markup
- Shopify-specific response headers and cookies

A score of 50 or greater is considered confirmed. The score and matched signals
are retained in the CSV so results can be audited.

## Secure ShopSignal sync

The `sync` command sends local SQLite results to the HTTPS ingestion endpoint in
batches. Every request is signed with HMAC-SHA256 and includes a timestamp and a
one-time nonce. The server rejects stale, modified, replayed, oversized, and
unknown-key requests. Batch IDs make retries idempotent.

On the ShopSignal server, add a random secret to `config.local.php`:

```php
'crawler_ingest_enabled' => true,
'crawler_ingest_require_https' => true,
'crawler_ingest_max_batch' => 100,
'crawler_ingest_keys' => [
    'home-scraper' => 'YOUR_64_CHARACTER_RANDOM_SECRET',
],
```

Generate the secret locally instead of inventing one:

```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Keep the secret out of shell history and source control. Read it without echoing
it, then export it for the current terminal session:

```bash
read -s SHOPSIGNAL_INGEST_SECRET
export SHOPSIGNAL_INGEST_SECRET
export SHOPSIGNAL_INGEST_KEY_ID='home-scraper'
export SHOPSIGNAL_INGEST_URL='https://onecom.io/shopsignal/api/ingest.php'
```

Then preview and run the first full sync:

```bash
shopify-spider sync --database shopify_spider.sqlite3 --dry-run
shopify-spider sync --database shopify_spider.sqlite3 --full
```

Later runs can omit `--full`. The successful sync cursor is kept in SQLite, so
only stores observed again after the previous completed sync are sent. Failed
batches do not advance the cursor and are safe to retry.

The sync is one-way and merge-only: remote stores are matched by normalized
domain, child records are upserted by stable source keys, and missing local
records are never interpreted as deletions. The ShopSignal admin dashboard shows
batch history and counts without displaying the secret.

## Choosing seeds

The spider is focused, not an internet-scale crawler. Useful seeds include
public merchant directories, trade-association member pages, niche blogs,
conference exhibitor lists, or a domain list you already possess. For broad
coverage, use the Common Crawl `discover` command to feed candidate URLs into
the same queue.

## Responsible operation

You are responsible for complying with applicable laws and website terms.
Keep request rates low, honor opt-outs, collect only the public fields you need,
and avoid using extracted contact information for unsolicited bulk messaging.
# onecom-scraper
