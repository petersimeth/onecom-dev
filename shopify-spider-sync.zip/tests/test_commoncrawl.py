import json
import tempfile
import unittest
from argparse import Namespace
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

from shopify_spider.cli import run_discover
from shopify_spider.commoncrawl import CommonCrawlError, CommonCrawlSource
from shopify_spider.storage import Storage


class FakeTransport:
    def __init__(self) -> None:
        self.urls: list[str] = []

    def __call__(self, url: str, timeout: float, user_agent: str) -> bytes:
        self.urls.append(url)
        self.timeout = timeout
        self.user_agent = user_agent
        if url.endswith("collinfo.json"):
            return json.dumps(
                [
                    {
                        "id": "CC-MAIN-2026-22",
                        "cdx-api": "https://index.commoncrawl.org/CC-MAIN-2026-22-index",
                    }
                ]
            ).encode()
        records = [
            {"url": "http://alpha.myshopify.com/products/hat", "status": "200"},
            {"url": "https://alpha.myshopify.com/collections/all", "status": "200"},
            {"url": "https://beta.myshopify.com/", "status": "200"},
            {"url": "not a url", "status": "200"},
        ]
        return ("\n".join(json.dumps(record) for record in records) + "\n").encode()


class CommonCrawlTests(unittest.TestCase):
    def test_discovers_unique_homepages_from_latest_collection(self) -> None:
        transport = FakeTransport()
        source = CommonCrawlSource("TestBot/1.0", timeout=12, transport=transport)

        result = source.discover(limit=10)

        self.assertEqual(result.collection, "CC-MAIN-2026-22")
        self.assertEqual(
            result.candidates,
            ["https://alpha.myshopify.com/", "https://beta.myshopify.com/"],
        )
        self.assertEqual(len(transport.urls), 2)
        query = parse_qs(urlsplit(transport.urls[1]).query)
        self.assertEqual(query["url"], ["*.myshopify.com/"])
        self.assertEqual(query["limit"], ["40"])
        self.assertEqual(query["filter"], ["status:200", "mime:text/html"])
        self.assertEqual(transport.timeout, 12)
        self.assertEqual(transport.user_agent, "TestBot/1.0")

    def test_explicit_collection_skips_collection_lookup_and_honors_limit(self) -> None:
        transport = FakeTransport()
        source = CommonCrawlSource("TestBot/1.0", transport=transport)

        result = source.discover(limit=1, collection="CC-MAIN-2026-22")

        self.assertEqual(result.candidates, ["https://alpha.myshopify.com/"])
        self.assertEqual(len(transport.urls), 1)
        self.assertIn("CC-MAIN-2026-22-index", transport.urls[0])

    def test_rejects_invalid_collection(self) -> None:
        source = CommonCrawlSource("TestBot/1.0", transport=FakeTransport())
        with self.assertRaises(CommonCrawlError):
            source.discover(collection="https://example.com/index")

    def test_discover_command_enqueues_candidates(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "crawl.sqlite3"
            source = CommonCrawlSource("TestBot/1.0", transport=FakeTransport())
            with patch("shopify_spider.cli.CommonCrawlSource", return_value=source):
                output = StringIO()
                with redirect_stdout(output):
                    code = run_discover(
                        Namespace(
                            user_agent="TestBot/1.0",
                            index_timeout=10,
                            limit=2,
                            query="*.myshopify.com/",
                            collection="CC-MAIN-2026-22",
                            database=str(database),
                            scan=False,
                        )
                    )

            self.assertEqual(code, 0)
            self.assertIn("added 2 new candidate(s)", output.getvalue())
            storage = Storage(database)
            try:
                self.assertEqual(storage.queue_counts(), {"pending": 2})
                rows = storage.next_pending_batch(2)
                self.assertEqual({row["kind"] for row in rows}, {"candidate"})
                self.assertEqual(
                    {row["source_url"] for row in rows},
                    {"commoncrawl:CC-MAIN-2026-22"},
                )
            finally:
                storage.close()


if __name__ == "__main__":
    unittest.main()
