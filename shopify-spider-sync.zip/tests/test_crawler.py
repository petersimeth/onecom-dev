import asyncio
import tempfile
import unittest
from pathlib import Path

from shopify_spider.crawler import CrawlConfig, Spider
from shopify_spider.models import FetchResult
from shopify_spider.storage import Storage


FIXTURE_BODY = """
<html lang="en"><head><title>Fixture Shop</title></head>
<body class="shopify-section">
  <script>
    Shopify.theme = {"name": "Fixture"};
    Shopify.shop = "fixture.myshopify.com";
  </script>
  <img src="/cdn/shop/files/logo.png">
  <a href="/products/hat">Hat</a>
</body></html>
"""


class FixtureFetcher:
    async def fetch(self, url: str) -> FetchResult:
        return FetchResult(url, url, 200, {"content-type": "text/html"}, FIXTURE_BODY)


class CrawlerTests(unittest.TestCase):
    def test_end_to_end_store_detection(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            storage = Storage(Path(directory) / "crawl.sqlite3")
            try:
                spider = Spider(
                    storage,
                    FixtureFetcher(),  # type: ignore[arg-type]
                    CrawlConfig(
                        max_pages=2,
                        max_domains=10,
                        discovery_depth=0,
                        store_depth=1,
                        pages_per_host=2,
                        concurrency=4,
                    ),
                )
                self.assertEqual(spider.add_seeds(["https://fixture.example/"]), 1)
                asyncio.run(spider.run())
                self.assertEqual(storage.store_count(), 1)
                self.assertEqual(spider.pages_processed, 2)
            finally:
                storage.close()


if __name__ == "__main__":
    unittest.main()
