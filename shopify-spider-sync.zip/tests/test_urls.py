import unittest

from shopify_spider.urls import (
    homepage_for,
    is_public_candidate,
    normalize_url,
    same_site,
)


class UrlTests(unittest.TestCase):
    def test_normalizes_domain_and_drops_query(self) -> None:
        self.assertEqual(
            normalize_url("Example.COM/products/hat?utm_source=x"),
            "https://example.com/products/hat",
        )

    def test_resolves_relative_url(self) -> None:
        self.assertEqual(
            normalize_url("../pages/about", "https://shop.example.com/products/hat"),
            "https://shop.example.com/pages/about",
        )

    def test_same_site_handles_subdomains(self) -> None:
        self.assertTrue(same_site("https://www.example.com", "https://shop.example.com/a"))

    def test_social_network_is_not_candidate(self) -> None:
        self.assertFalse(is_public_candidate("https://instagram.com/example"))

    def test_rejects_hostname_with_whitespace(self) -> None:
        self.assertIsNone(normalize_url("not a url"))

    def test_homepage(self) -> None:
        self.assertEqual(homepage_for("https://example.com/a"), "https://example.com/")


if __name__ == "__main__":
    unittest.main()
