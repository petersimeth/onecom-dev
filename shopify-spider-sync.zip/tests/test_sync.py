import hashlib
import hmac
import json
import unittest

from shopify_spider.sync import _bounded_batches, signature_headers


class SyncTests(unittest.TestCase):
    def test_signature_matches_server_contract(self) -> None:
        body = json.dumps({"schema_version": 1}, sort_keys=True).encode("utf-8")
        secret = "a" * 64
        headers = signature_headers(
            body,
            "home-scraper",
            secret,
            timestamp=1_800_000_000,
            nonce="nonce-1234567890abcdef",
        )
        body_hash = hashlib.sha256(body).hexdigest()
        signing_input = (
            "shopsignal-ingest-v1\n1800000000\nnonce-1234567890abcdef\n" + body_hash
        )
        expected = hmac.new(
            secret.encode("utf-8"), signing_input.encode("utf-8"), hashlib.sha256
        ).hexdigest()
        self.assertEqual(headers["X-ShopSignal-Signature"], expected)

    def test_batches_respect_record_limit(self) -> None:
        records = [{"domain": f"store-{index}.example"} for index in range(5)]
        batches = list(_bounded_batches(records, 2))
        self.assertEqual([len(batch) for batch in batches], [2, 2, 1])


if __name__ == "__main__":
    unittest.main()
