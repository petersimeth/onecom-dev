import unittest

from shopify_spider.detector import detect_shopify


class DetectorTests(unittest.TestCase):
    def test_detects_multiple_shopify_signals(self) -> None:
        body = """
        <html><head><script>
        Shopify.theme = {"name": "Dawn"};
        Shopify.shop = "example.myshopify.com";
        </script></head>
        <body><img src="/cdn/shop/files/logo.png"></body></html>
        """
        result = detect_shopify(body)
        self.assertTrue(result.is_shopify)
        self.assertEqual(result.confidence, 100)
        self.assertEqual(result.myshopify_domain, "example.myshopify.com")

    def test_rejects_generic_storefront(self) -> None:
        result = detect_shopify(
            "<html><title>Store</title><a href='/products/hat'>Hat</a></html>"
        )
        self.assertFalse(result.is_shopify)
        self.assertLess(result.confidence, 50)

    def test_header_can_confirm_shopify(self) -> None:
        result = detect_shopify("<html></html>", {"X-ShopId": "123"})
        self.assertTrue(result.is_shopify)


if __name__ == "__main__":
    unittest.main()
