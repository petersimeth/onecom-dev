import logging
import tempfile
import unittest
from contextlib import redirect_stderr
from io import StringIO
from pathlib import Path

from shopify_spider.cli import build_parser
from shopify_spider.logging_utils import (
    configure_logging,
    pause_console_logging,
    shutdown_logging,
)


class LoggingTests(unittest.TestCase):
    def tearDown(self) -> None:
        shutdown_logging()

    def test_writes_selected_levels_to_rotating_file(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            log_path = Path(directory) / "logs" / "spider.log"
            configure_logging("DEBUG", log_path)
            logger = logging.getLogger("shopify_spider.test")

            logger.debug("candidate queued")
            logger.info("store detected")
            shutdown_logging()

            content = log_path.read_text(encoding="utf-8")
            self.assertIn("DEBUG shopify_spider.test candidate queued", content)
            self.assertIn("INFO shopify_spider.test store detected", content)

    def test_reconfiguration_does_not_duplicate_handlers(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            log_path = Path(directory) / "spider.log"
            configure_logging("INFO", log_path)
            configure_logging("INFO", log_path)
            logging.getLogger("shopify_spider.test").info("one copy")
            shutdown_logging()

            content = log_path.read_text(encoding="utf-8")
            self.assertEqual(content.count("one copy"), 1)

    def test_log_file_rotates_at_configured_size(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            log_path = Path(directory) / "spider.log"
            configure_logging("INFO", log_path, max_bytes=200, backup_count=1)
            logger = logging.getLogger("shopify_spider.test")
            for index in range(10):
                logger.info("rotation record=%d payload=%s", index, "x" * 80)
            shutdown_logging()

            self.assertTrue(Path(f"{log_path}.1").exists())

    def test_console_logging_can_pause_for_progress_bar(self) -> None:
        stderr = StringIO()
        with redirect_stderr(stderr):
            configure_logging("INFO", verbose=True)
            logger = logging.getLogger("shopify_spider.test")
            logger.info("visible before")
            with pause_console_logging():
                logger.error("hidden during progress")
            logger.info("visible after")
            shutdown_logging()

        output = stderr.getvalue()
        self.assertIn("visible before", output)
        self.assertNotIn("hidden during progress", output)
        self.assertIn("visible after", output)

    def test_cli_accepts_logging_options(self) -> None:
        args = build_parser().parse_args(
            [
                "scan",
                "seeds.txt",
                "--log-file",
                "spider.log",
                "--log-level",
                "DEBUG",
                "--verbose",
            ]
        )
        self.assertEqual(args.log_file, "spider.log")
        self.assertEqual(args.log_level, "DEBUG")
        self.assertTrue(args.verbose)


if __name__ == "__main__":
    unittest.main()
