import unittest

from shopify_spider.html import parse_metadata


class HtmlTests(unittest.TestCase):
    def test_extracts_public_metadata(self) -> None:
        body = """
        <html lang="en"><head>
          <title> Example Shop </title>
          <meta name="description" content="Useful things">
        </head><body>
          <a href="/products/hat">Hat</a>
          <a href="https://instagram.com/example">Instagram</a>
          <p>hello@example.com</p>
          <script>window.currencyCode = "USD";</script>
          <script src="https://static.klaviyo.com/onsite/js/fixture.js"></script>
          <script type="application/ld+json">
            {"@type":"Product","name":"Canvas Hat","category":"Accessories",
             "url":"/products/hat","offers":{"price":"29.50","priceCurrency":"USD"}}
          </script>
        </body></html>
        """
        result = parse_metadata(body, "https://example.com/")
        self.assertEqual(result.title, "Example Shop")
        self.assertEqual(result.description, "Useful things")
        self.assertEqual(result.language, "en")
        self.assertEqual(result.currency, "USD")
        self.assertIn("hello@example.com", result.emails)
        self.assertIn("https://example.com/products/hat", result.links)
        self.assertEqual(result.technologies[0].name, "Klaviyo")
        self.assertEqual(result.products[0].name, "Canvas Hat")
        self.assertEqual(result.products[0].price, 29.5)
        self.assertEqual(result.products[0].url, "https://example.com/products/hat")


if __name__ == "__main__":
    unittest.main()
