import tempfile
import unittest
from pathlib import Path

from shopify_spider.models import DetectionResult, PageMetadata, ProductRecord, TechnologyRecord
from shopify_spider.storage import Storage


class StorageTests(unittest.TestCase):
    def test_queue_resume_and_export(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database = Path(directory) / "test.sqlite3"
            output = Path(directory) / "stores.csv"
            storage = Storage(database)
            try:
                self.assertTrue(storage.enqueue("https://example.com/", None, 0, "discovery"))
                self.assertFalse(storage.enqueue("https://example.com/", None, 0, "discovery"))
                row = storage.next_pending()
                self.assertEqual(row["url"], "https://example.com/")
                storage.reset_running()
                self.assertEqual(storage.next_pending()["status"], "pending")
                storage.finish("https://example.com/")
                storage.save_store(
                    "example.com",
                    "https://example.com/",
                    "https://example.com/",
                    PageMetadata(title="Example"),
                    DetectionResult(True, 90, ["signal"]),
                    None,
                )
                self.assertEqual(storage.export_csv(output), 1)
                self.assertIn("example.com", output.read_text(encoding="utf-8"))
            finally:
                storage.close()

    def test_batch_enqueue_and_dequeue(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            storage = Storage(Path(directory) / "test.sqlite3")
            try:
                rows = [
                    ("https://one.example/", None, 0, "discovery"),
                    ("https://two.example/", None, 0, "discovery"),
                    ("https://three.example/", None, 0, "discovery"),
                ]
                self.assertEqual(storage.enqueue_many(rows), 3)
                self.assertEqual(storage.enqueue_many(rows), 0)

                batch = storage.next_pending_batch(2)
                self.assertEqual(
                    [row["url"] for row in batch],
                    ["https://one.example/", "https://two.example/"],
                )
                self.assertEqual(storage.queue_counts(), {"pending": 1, "running": 2})
            finally:
                storage.close()

    def test_batch_discoveries_are_saved(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            storage = Storage(Path(directory) / "test.sqlite3")
            try:
                rows = [
                    (
                        "https://source.example/",
                        "https://store.example/",
                        "store.example",
                    )
                ]
                self.assertEqual(storage.save_discoveries_many(rows), 1)
                self.assertEqual(storage.save_discoveries_many(rows), 0)
            finally:
                storage.close()

    def test_intelligence_records_are_available_for_sync(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            storage = Storage(Path(directory) / "test.sqlite3")
            try:
                metadata = PageMetadata(
                    title="Example Shop",
                    technologies=[TechnologyRecord("Klaviyo", "Email marketing", "kl")],
                    products=[
                        ProductRecord(
                            "Canvas Hat", "Accessories", 29.5, "USD", "https://example.com/products/hat"
                        )
                    ],
                )
                created = storage.save_store(
                    "example.com",
                    "https://example.com/",
                    "https://example.com/",
                    metadata,
                    DetectionResult(True, 90, ["cdn_shopify"]),
                    None,
                )
                self.assertTrue(created)
                counts = storage.save_intelligence("example.com", metadata, created)
                self.assertEqual(counts, {"technologies": 1, "products": 1, "signals": 1})
                record = storage.records_for_sync()[0]
                self.assertEqual(record["domain"], "example.com")
                self.assertEqual(record["technologies"][0]["name"], "Klaviyo")
                self.assertEqual(record["products"][0]["name"], "Canvas Hat")
                self.assertEqual(record["signals"][0]["type"], "discovery")
            finally:
                storage.close()


if __name__ == "__main__":
    unittest.main()
