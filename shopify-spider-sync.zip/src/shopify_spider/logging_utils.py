from __future__ import annotations

import logging
from contextlib import contextmanager
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Iterator


LOGGER_NAME = "shopify_spider"
LOG_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
_HANDLER_MARKER = "_shopify_spider_handler"


def configure_logging(
    level: str = "INFO",
    log_file: str | Path | None = None,
    verbose: bool = False,
    max_bytes: int = 5_000_000,
    backup_count: int = 3,
) -> logging.Logger:
    """Configure package logging without modifying the application's root logger."""
    numeric_level = _numeric_level(level)
    logger = logging.getLogger(LOGGER_NAME)
    logger.propagate = False
    _remove_owned_handlers(logger)

    console = logging.StreamHandler()
    console.setLevel(numeric_level if verbose else logging.WARNING)
    console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    setattr(console, _HANDLER_MARKER, "console")
    logger.addHandler(console)

    if log_file:
        path = Path(log_file).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            path,
            maxBytes=max(1, max_bytes),
            backupCount=max(0, backup_count),
            encoding="utf-8",
        )
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)s %(name)s %(message)s",
                datefmt="%Y-%m-%dT%H:%M:%S%z",
            )
        )
        setattr(file_handler, _HANDLER_MARKER, "file")
        logger.addHandler(file_handler)

    handler_levels = [handler.level for handler in logger.handlers]
    logger.setLevel(min(handler_levels, default=numeric_level))
    logger.info(
        "logging configured level=%s file=%s verbose=%s",
        logging.getLevelName(numeric_level),
        str(log_file) if log_file else "disabled",
        verbose,
    )
    return logger


def shutdown_logging() -> None:
    """Flush and close handlers created by :func:`configure_logging`."""
    _remove_owned_handlers(logging.getLogger(LOGGER_NAME))


@contextmanager
def pause_console_logging(enabled: bool = True) -> Iterator[None]:
    """Temporarily silence package console handlers while a progress bar is active."""
    if not enabled:
        yield
        return
    logger = logging.getLogger(LOGGER_NAME)
    levels: list[tuple[logging.Handler, int]] = []
    for handler in logger.handlers:
        if getattr(handler, _HANDLER_MARKER, None) == "console":
            levels.append((handler, handler.level))
            handler.setLevel(logging.CRITICAL + 1)
    try:
        yield
    finally:
        for handler, level in levels:
            handler.setLevel(level)


def _numeric_level(level: str) -> int:
    normalized = level.upper()
    if normalized not in LOG_LEVELS:
        raise ValueError(f"Invalid log level: {level}")
    return int(getattr(logging, normalized))


def _remove_owned_handlers(logger: logging.Logger) -> None:
    for handler in list(logger.handlers):
        if getattr(handler, _HANDLER_MARKER, None):
            logger.removeHandler(handler)
            handler.flush()
            handler.close()
