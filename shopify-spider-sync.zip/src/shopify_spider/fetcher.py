from __future__ import annotations

import asyncio
import logging
import time
import urllib.error
import urllib.request
import urllib.robotparser
from collections import defaultdict
from urllib.parse import urlsplit

from .models import FetchResult
from .urls import origin


logger = logging.getLogger(__name__)


class PoliteFetcher:
    def __init__(
        self,
        user_agent: str,
        delay: float = 1.0,
        timeout: float = 15.0,
        max_bytes: int = 2_000_000,
        obey_robots: bool = True,
    ) -> None:
        self.user_agent = user_agent
        self.delay = max(0.0, delay)
        self.timeout = timeout
        self.max_bytes = max_bytes
        self.obey_robots = obey_robots
        self._locks: defaultdict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
        self._last_request: dict[str, float] = {}
        self._robots: dict[str, urllib.robotparser.RobotFileParser | None] = {}

    async def allowed(self, url: str) -> bool:
        if not self.obey_robots:
            return True
        site_origin = origin(url)
        if site_origin not in self._robots:
            self._robots[site_origin] = await asyncio.to_thread(self._load_robots, site_origin)
        parser = self._robots[site_origin]
        allowed = True if parser is None else parser.can_fetch(self.user_agent, url)
        logger.debug("robots decision allowed=%s url=%s", allowed, url)
        return allowed

    def _load_robots(self, site_origin: str) -> urllib.robotparser.RobotFileParser | None:
        robots_url = site_origin + "/robots.txt"
        request = urllib.request.Request(
            robots_url,
            headers={"User-Agent": self.user_agent, "Accept": "text/plain,*/*;q=0.1"},
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read(min(self.max_bytes, 512_000))
            parser = urllib.robotparser.RobotFileParser()
            parser.set_url(robots_url)
            parser.parse(raw.decode("utf-8", errors="replace").splitlines())
            return parser
        except (OSError, urllib.error.URLError, urllib.error.HTTPError) as error:
            logger.debug("robots unavailable url=%s error=%s", robots_url, error)
            return None

    async def fetch(self, url: str) -> FetchResult:
        host = urlsplit(url).netloc.lower()
        async with self._locks[host]:
            if self.obey_robots:
                site_origin = origin(url)
                if site_origin not in self._robots:
                    await self._wait_for_host(host)
                    self._robots[site_origin] = await asyncio.to_thread(
                        self._load_robots, site_origin
                    )
                    self._last_request[host] = time.monotonic()
                parser = self._robots[site_origin]
                if parser is not None and not parser.can_fetch(self.user_agent, url):
                    logger.info("request blocked by robots url=%s", url)
                    return FetchResult(url, url, 0, {}, "", "blocked by robots.txt")

            await self._wait_for_host(host)
            result = await asyncio.to_thread(self._fetch_sync, url)
            self._last_request[host] = time.monotonic()
            logger.debug(
                "request complete status=%d bytes=%d error=%s url=%s final_url=%s",
                result.status,
                len(result.body),
                result.error or "none",
                url,
                result.final_url,
            )
            return result

    async def _wait_for_host(self, host: str) -> None:
        elapsed = time.monotonic() - self._last_request.get(host, 0.0)
        if elapsed < self.delay:
            logger.debug("rate limit wait host=%s seconds=%.3f", host, self.delay - elapsed)
            await asyncio.sleep(self.delay - elapsed)

    def _fetch_sync(self, url: str) -> FetchResult:
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": self.user_agent,
                "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.1",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                status = response.status
                headers = {key.lower(): value for key, value in response.headers.items()}
                content_type = headers.get("content-type", "")
                if "text/html" not in content_type and "application/xhtml+xml" not in content_type:
                    return FetchResult(url, response.url, status, headers, "")
                raw = response.read(self.max_bytes + 1)
                if len(raw) > self.max_bytes:
                    raw = raw[: self.max_bytes]
                charset = response.headers.get_content_charset() or "utf-8"
                body = raw.decode(charset, errors="replace")
                return FetchResult(url, response.url, status, headers, body)
        except urllib.error.HTTPError as error:
            return FetchResult(url, error.url, error.code, dict(error.headers.items()), "", str(error))
        except (OSError, urllib.error.URLError, ValueError) as error:
            return FetchResult(url, url, 0, {}, "", str(error))
