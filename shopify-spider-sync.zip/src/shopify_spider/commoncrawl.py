from __future__ import annotations

import json
import logging
import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Callable

from .urls import host_for, is_public_candidate, normalize_url


logger = logging.getLogger(__name__)


COLLECTIONS_URL = "https://index.commoncrawl.org/collinfo.json"
DEFAULT_QUERY = "*.myshopify.com/"
MAX_CANDIDATES = 5_000

Transport = Callable[[str, float, str], bytes]


class CommonCrawlError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class DiscoveryResult:
    collection: str
    query: str
    candidates: list[str]


class CommonCrawlSource:
    """Small, bounded client for Common Crawl's public CDX index."""

    def __init__(
        self,
        user_agent: str,
        timeout: float = 30.0,
        transport: Transport | None = None,
    ) -> None:
        self.user_agent = user_agent
        self.timeout = max(1.0, timeout)
        self._transport = transport

    def discover(
        self,
        limit: int = 500,
        query: str = DEFAULT_QUERY,
        collection: str | None = None,
    ) -> DiscoveryResult:
        limit = max(1, min(limit, MAX_CANDIDATES))
        query = query.strip()
        if not query:
            raise CommonCrawlError("Common Crawl query cannot be empty")
        collection_id, endpoint = self._resolve_collection(collection)
        record_limit = min(MAX_CANDIDATES, limit * 4)
        logger.info(
            "Common Crawl discovery started collection=%s query=%s candidate_limit=%d",
            collection_id,
            query,
            limit,
        )
        parameters = urllib.parse.urlencode(
            [
                ("url", query),
                ("output", "json"),
                ("fl", "url,status,mime"),
                ("filter", "status:200"),
                ("filter", "mime:text/html"),
                ("collapse", "urlkey"),
                ("limit", str(record_limit)),
            ]
        )
        payload = self._get(f"{endpoint}?{parameters}").decode("utf-8", errors="replace")

        candidates: list[str] = []
        seen_hosts: set[str] = set()
        malformed_records = 0
        for line in payload.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                malformed_records += 1
                continue
            candidate = self._candidate_homepage(str(record.get("url", "")))
            if candidate is None:
                continue
            host = host_for(candidate)
            if host in seen_hosts:
                continue
            seen_hosts.add(host)
            candidates.append(candidate)
            if len(candidates) >= limit:
                break
        logger.info(
            "Common Crawl discovery finished collection=%s candidates=%d malformed=%d",
            collection_id,
            len(candidates),
            malformed_records,
        )
        return DiscoveryResult(collection_id, query, candidates)

    def _resolve_collection(self, collection: str | None) -> tuple[str, str]:
        if collection:
            collection = collection.removesuffix("-index")
            if re.fullmatch(r"CC-MAIN-\d{4}-\d{2}", collection) is None:
                raise CommonCrawlError(f"Invalid Common Crawl collection: {collection}")
            logger.debug("using pinned Common Crawl collection=%s", collection)
            return collection, f"https://index.commoncrawl.org/{collection}-index"

        try:
            collections = json.loads(self._get(COLLECTIONS_URL))
        except json.JSONDecodeError as error:
            raise CommonCrawlError("Common Crawl returned an invalid collection list") from error
        if not isinstance(collections, list) or not collections:
            raise CommonCrawlError("Common Crawl returned an empty collection list")
        latest = collections[0]
        collection_id = str(latest.get("id", ""))
        endpoint = str(latest.get("cdx-api", ""))
        if not collection_id or not endpoint.startswith("https://index.commoncrawl.org/"):
            raise CommonCrawlError("Common Crawl collection metadata is incomplete")
        logger.debug("selected latest Common Crawl collection=%s", collection_id)
        return collection_id, endpoint

    def _candidate_homepage(self, value: str) -> str | None:
        normalized = normalize_url(value)
        if normalized is None or not is_public_candidate(normalized):
            return None
        host = host_for(normalized)
        if not host:
            return None
        return f"https://{host}/"

    def _get(self, url: str) -> bytes:
        try:
            if self._transport is not None:
                payload = self._transport(url, self.timeout, self.user_agent)
                logger.debug("Common Crawl response bytes=%d url=%s", len(payload), url)
                return payload
            request = urllib.request.Request(
                url,
                headers={
                    "User-Agent": self.user_agent,
                    "Accept": "application/json,application/x-ndjson,text/plain;q=0.8",
                },
            )
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                payload = response.read(10_000_000)
            logger.debug("Common Crawl response bytes=%d url=%s", len(payload), url)
            return payload
        except (OSError, urllib.error.HTTPError, urllib.error.URLError) as error:
            logger.warning("Common Crawl request failed url=%s error=%s", url, error)
            raise CommonCrawlError(f"Common Crawl request failed: {error}") from error
