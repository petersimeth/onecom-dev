from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import hmac
import json
import logging
import os
import time
from typing import Iterable
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from uuid import uuid4

from .storage import Storage


logger = logging.getLogger(__name__)
SCHEMA_VERSION = 1


class SyncError(RuntimeError):
    pass


@dataclass(slots=True)
class SyncResult:
    stores: int = 0
    created: int = 0
    updated: int = 0
    technologies: int = 0
    products: int = 0
    signals: int = 0
    batches: int = 0


def signature_headers(
    body: bytes,
    key_id: str,
    secret: str,
    timestamp: int | None = None,
    nonce: str | None = None,
) -> dict[str, str]:
    timestamp_text = str(timestamp if timestamp is not None else int(time.time()))
    nonce_value = nonce or uuid4().hex
    body_hash = hashlib.sha256(body).hexdigest()
    signing_input = f"shopsignal-ingest-v1\n{timestamp_text}\n{nonce_value}\n{body_hash}"
    signature = hmac.new(
        secret.encode("utf-8"), signing_input.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    return {
        "X-ShopSignal-Key": key_id,
        "X-ShopSignal-Timestamp": timestamp_text,
        "X-ShopSignal-Nonce": nonce_value,
        "X-ShopSignal-Signature": signature,
    }


class SyncClient:
    def __init__(
        self,
        endpoint: str,
        key_id: str,
        secret: str,
        timeout: float = 30.0,
        retries: int = 3,
    ) -> None:
        endpoint = endpoint.strip()
        parts = urlsplit(endpoint)
        local = (parts.hostname or "").lower() in {"localhost", "127.0.0.1", "::1"}
        if parts.scheme != "https" and not (local and parts.scheme == "http"):
            raise ValueError("The ingestion endpoint must use HTTPS.")
        if not key_id or len(secret) < 32:
            raise ValueError("A key ID and secret of at least 32 characters are required.")
        self.endpoint = endpoint
        self.key_id = key_id
        self.secret = secret
        self.timeout = max(1.0, timeout)
        self.retries = max(0, min(10, retries))

    def send(self, payload: dict[str, object]) -> dict[str, object]:
        body = json.dumps(
            payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        last_error: Exception | None = None
        for attempt in range(self.retries + 1):
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": "ShopifyStoreSpiderSync/1.0",
                **signature_headers(body, self.key_id, self.secret),
            }
            request = Request(self.endpoint, data=body, headers=headers, method="POST")
            try:
                with urlopen(request, timeout=self.timeout) as response:
                    response_body = response.read(2_000_000)
                decoded = json.loads(response_body.decode("utf-8"))
                if not isinstance(decoded, dict) or not decoded.get("ok"):
                    raise SyncError(str(decoded.get("message", "Invalid ingestion response.")))
                return decoded
            except HTTPError as error:
                response_body = error.read(64_000)
                try:
                    decoded = json.loads(response_body.decode("utf-8"))
                    message = str(decoded.get("message", f"HTTP {error.code}"))
                except (UnicodeDecodeError, ValueError, json.JSONDecodeError):
                    message = f"HTTP {error.code}"
                last_error = SyncError(message)
                if error.code < 500 and error.code != 429:
                    raise last_error from error
            except (URLError, TimeoutError, OSError, json.JSONDecodeError) as error:
                last_error = error

            if attempt < self.retries:
                delay = min(10.0, 0.75 * (2**attempt))
                logger.warning(
                    "sync request failed attempt=%d retry_in=%.2f error=%s",
                    attempt + 1,
                    delay,
                    last_error,
                )
                time.sleep(delay)

        raise SyncError(f"Sync failed after {self.retries + 1} attempt(s): {last_error}")


def sync_database(
    storage: Storage,
    client: SyncClient,
    batch_size: int = 100,
    full: bool = False,
    dry_run: bool = False,
) -> SyncResult:
    started_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    since = None if full else storage.get_sync_cursor()
    records = storage.records_for_sync(since)
    result = SyncResult(stores=len(records))
    if dry_run or not records:
        return result

    sent_at = datetime.now(timezone.utc).isoformat()
    batches = list(_bounded_batches(records, max(1, min(100, batch_size))))
    for index, batch in enumerate(batches, 1):
        payload: dict[str, object] = {
            "schema_version": SCHEMA_VERSION,
            "batch_id": "spider-" + uuid4().hex,
            "source": "shopify-spider-home",
            "sent_at": sent_at,
            "stores": batch,
        }
        response = client.send(payload)
        summary = response.get("summary", {})
        if not isinstance(summary, dict):
            raise SyncError("The server response did not include a valid summary.")
        result.created += int(summary.get("stores_created", 0))
        result.updated += int(summary.get("stores_updated", 0))
        result.technologies += int(summary.get("technologies_upserted", 0))
        result.products += int(summary.get("products_upserted", 0))
        result.signals += int(summary.get("signals_upserted", 0))
        result.batches += 1
        print(
            f"Synced batch {index}/{len(batches)}: {len(batch)} store(s), "
            f"{int(summary.get('stores_created', 0))} new, "
            f"{int(summary.get('stores_updated', 0))} updated."
        )

    storage.set_sync_cursor(started_at)
    return result


def secret_from_environment(variable: str = "SHOPSIGNAL_INGEST_SECRET") -> str:
    secret = os.environ.get(variable, "").strip()
    if not secret:
        raise ValueError(f"Set {variable} before syncing.")
    return secret


def _bounded_batches(
    records: Iterable[dict[str, object]], batch_size: int, max_body_bytes: int = 1_500_000
):
    batch: list[dict[str, object]] = []
    estimated = 300
    for record in records:
        record_size = len(
            json.dumps(record, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        )
        if batch and (len(batch) >= batch_size or estimated + record_size > max_body_bytes):
            yield batch
            batch = []
            estimated = 300
        if record_size > max_body_bytes:
            raise SyncError(f"Store payload is too large: {record.get('domain', 'unknown')}")
        batch.append(record)
        estimated += record_size
    if batch:
        yield batch
