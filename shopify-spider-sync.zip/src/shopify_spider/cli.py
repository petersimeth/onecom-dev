from __future__ import annotations

import argparse
import asyncio
import logging
import os
import shutil
import sys
from pathlib import Path

from . import __version__
from .commoncrawl import DEFAULT_QUERY, CommonCrawlError, CommonCrawlSource
from .crawler import CrawlConfig, CrawlProgress, ProgressCallback, Spider, read_seeds
from .fetcher import PoliteFetcher
from .logging_utils import (
    LOG_LEVELS,
    configure_logging,
    pause_console_logging,
    shutdown_logging,
)
from .storage import Storage
from .sync import SyncClient, SyncError, secret_from_environment, sync_database


DEFAULT_UA = "ShopifyStoreResearchBot/0.1 (public-store-discovery)"
logger = logging.getLogger(__name__)


class ProgressBar:
    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled and sys.stderr.isatty()
        self._last_length = 0

    def update(self, progress: CrawlProgress) -> None:
        if not self.enabled:
            return
        width = max(12, min(30, shutil.get_terminal_size((80, 20)).columns - 72))
        ratio = min(1.0, progress.processed / max(1, progress.max_pages))
        filled = int(width * ratio)
        bar = "#" * filled + "-" * (width - filled)
        counts = progress.queue_counts
        pending = counts.get("pending", 0)
        failed = counts.get("failed", 0)
        current = _shorten(progress.current_url or progress.message, 32)
        line = (
            f"\r[{bar}] {progress.processed}/{progress.max_pages} pages "
            f"| stores {progress.stores_found} | pending {pending} | failed {failed} "
            f"| {current}"
        )
        padding = " " * max(0, self._last_length - len(line))
        print(line + padding, end="", file=sys.stderr, flush=True)
        self._last_length = len(line)

    def finish(self) -> None:
        if self.enabled and self._last_length:
            print(file=sys.stderr)
            self._last_length = 0


def _shorten(value: str, limit: int) -> str:
    value = value.replace("\n", " ").strip()
    if len(value) <= limit:
        return value
    return value[: max(0, limit - 1)] + "…"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="shopify-spider",
        description="Discover and identify public Shopify stores from public web data.",
    )
    parser.add_argument("--version", action="version", version=__version__)
    subparsers = parser.add_subparsers(dest="command")

    menu = subparsers.add_parser("menu", help="Open an interactive menu")
    _add_logging_options(menu)

    scan = subparsers.add_parser("scan", help="Crawl seeds and discover Shopify stores")
    scan.add_argument("seeds", help="TXT or one-column CSV file containing seed URLs/domains")
    _add_crawl_options(scan, discovery_depth=2)

    discover = subparsers.add_parser(
        "discover", help="Find candidate storefronts through Common Crawl"
    )
    discover.add_argument("--limit", type=int, default=500, help="Maximum unique candidates")
    discover.add_argument("--query", default=DEFAULT_QUERY, help="Common Crawl URL pattern")
    discover.add_argument(
        "--collection", help="Crawl ID such as CC-MAIN-2026-22; defaults to latest"
    )
    discover.add_argument("--index-timeout", type=float, default=30.0)
    discover.add_argument(
        "--scan", action="store_true", help="Immediately validate the discovered candidates"
    )
    _add_crawl_options(discover, discovery_depth=0)

    export = subparsers.add_parser("export", help="Export stores from an existing database")
    export.add_argument("--database", default="shopify_spider.sqlite3")
    export.add_argument("--output", default="stores.csv")
    _add_logging_options(export)

    status = subparsers.add_parser("status", help="Show database crawl status")
    status.add_argument("--database", default="shopify_spider.sqlite3")
    _add_logging_options(status)

    sync = subparsers.add_parser(
        "sync", help="Securely sync local store intelligence to ShopSignal"
    )
    sync.add_argument("--database", default="shopify_spider.sqlite3")
    sync.add_argument(
        "--endpoint",
        default=os.environ.get(
            "SHOPSIGNAL_INGEST_URL", "https://onecom.io/shopsignal/api/ingest.php"
        ),
    )
    sync.add_argument(
        "--key-id", default=os.environ.get("SHOPSIGNAL_INGEST_KEY_ID", "home-scraper")
    )
    sync.add_argument("--secret-env", default="SHOPSIGNAL_INGEST_SECRET")
    sync.add_argument("--batch-size", type=int, default=100)
    sync.add_argument("--timeout", type=float, default=30.0)
    sync.add_argument("--retries", type=int, default=3)
    sync.add_argument("--full", action="store_true", help="Sync every local store")
    sync.add_argument("--dry-run", action="store_true", help="Show the number of pending stores without sending")
    _add_logging_options(sync)
    return parser


def _add_crawl_options(command: argparse.ArgumentParser, discovery_depth: int) -> None:
    command.add_argument("--database", default="shopify_spider.sqlite3")
    command.add_argument("--output", default="stores.csv")
    command.add_argument("--max-pages", type=int, default=250)
    command.add_argument("--max-domains", type=int, default=500)
    command.add_argument("--depth", type=int, default=discovery_depth, help="Discovery crawl depth")
    command.add_argument("--store-depth", type=int, default=1)
    command.add_argument("--pages-per-host", type=int, default=8)
    command.add_argument("--concurrency", type=int, default=4)
    command.add_argument(
        "--delay", type=float, default=1.0, help="Seconds between requests per host"
    )
    command.add_argument("--timeout", type=float, default=15.0)
    command.add_argument("--user-agent", default=DEFAULT_UA)
    command.add_argument("--no-progress", action="store_true", help="Disable the live progress bar")
    command.add_argument(
        "--ignore-robots",
        action="store_true",
        help="Ignore robots.txt (not recommended; intended for controlled local testing)",
    )
    _add_logging_options(command)


def _add_logging_options(command: argparse.ArgumentParser) -> None:
    command.add_argument("--log-file", help="Write rotating logs to this file")
    command.add_argument(
        "--log-level",
        choices=LOG_LEVELS,
        default="INFO",
        help="File and verbose-console log level (default: INFO)",
    )
    command.add_argument(
        "--verbose",
        action="store_true",
        help="Show logs in the terminal; disables the live progress bar",
    )


def run_scan(args: argparse.Namespace) -> int:
    seed_path = Path(args.seeds)
    if not seed_path.exists():
        logger.error("seed file not found path=%s", seed_path)
        print(f"Seed file not found: {seed_path}", file=sys.stderr)
        return 2

    storage = Storage(args.database)
    try:
        spider = _build_spider(storage, args)
        added = spider.add_seeds(read_seeds(seed_path))
        logger.info("seed scan prepared path=%s added=%d", seed_path, added)
        print(f"Added {added} new seed URL(s). Starting crawl...")
        return _run_spider(storage, spider, args)
    finally:
        storage.close()


def run_discover(args: argparse.Namespace) -> int:
    source = CommonCrawlSource(
        user_agent=args.user_agent,
        timeout=max(1.0, args.index_timeout),
    )
    try:
        result = source.discover(
            limit=max(1, args.limit),
            query=args.query,
            collection=args.collection,
        )
    except CommonCrawlError as error:
        logger.error("Common Crawl discovery failed error=%s", error)
        print(str(error), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        logger.warning("Common Crawl discovery interrupted")
        print("\nDiscovery interrupted before the crawl queue was changed.")
        return 130

    storage = Storage(args.database)
    try:
        source_name = f"commoncrawl:{result.collection}"
        rows = [(url, source_name, 0, "candidate") for url in result.candidates]
        added = storage.enqueue_many(rows)
        logger.info(
            "discovery queued collection=%s candidates=%d added=%d database=%s",
            result.collection,
            len(result.candidates),
            added,
            args.database,
        )
        print(
            f"Common Crawl {result.collection}: found {len(result.candidates)} unique "
            f"candidate(s); added {added} new candidate(s) to {args.database}."
        )
        if not args.scan:
            print("Run this command again with --scan to validate queued candidates.")
            return 0
        print("Starting candidate validation...")
        return _run_spider(storage, _build_spider(storage, args), args)
    finally:
        storage.close()


def _build_spider(storage: Storage, args: argparse.Namespace) -> Spider:
    return Spider(
        storage,
        PoliteFetcher(
            user_agent=args.user_agent,
            delay=args.delay,
            timeout=args.timeout,
            obey_robots=not args.ignore_robots,
        ),
        CrawlConfig(
            max_pages=max(1, args.max_pages),
            max_domains=max(1, args.max_domains),
            discovery_depth=max(0, args.depth),
            store_depth=max(0, args.store_depth),
            pages_per_host=max(1, args.pages_per_host),
            concurrency=max(1, args.concurrency),
        ),
    )


def _run_spider(storage: Storage, spider: Spider, args: argparse.Namespace) -> int:
    progress_bar = ProgressBar(
        enabled=not getattr(args, "no_progress", False)
        and not getattr(args, "verbose", False)
    )
    try:
        progress_callback: ProgressCallback | None = (
            progress_bar.update if progress_bar.enabled else None
        )
        with pause_console_logging(progress_bar.enabled):
            asyncio.run(spider.run(progress_callback=progress_callback))
        progress_bar.finish()
        exported = storage.export_csv(args.output)
        logger.info(
            "crawl command complete processed=%d stores=%d exported=%d output=%s",
            spider.pages_processed,
            storage.store_count(),
            exported,
            args.output,
        )
        print(
            f"Processed {spider.pages_processed} page(s); "
            f"found {storage.store_count()} Shopify store(s); "
            f"exported {exported} row(s) to {args.output}."
        )
        return 0
    except KeyboardInterrupt:
        progress_bar.finish()
        logger.warning("crawl interrupted processed=%d", spider.pages_processed)
        print("\nCrawl interrupted. Progress is saved; run the same command to resume.")
        return 130


def run_export(args: argparse.Namespace) -> int:
    storage = Storage(args.database)
    try:
        count = storage.export_csv(args.output)
        logger.info("manual export complete stores=%d output=%s", count, args.output)
        print(f"Exported {count} store(s) to {args.output}.")
        return 0
    finally:
        storage.close()


def run_status(args: argparse.Namespace) -> int:
    storage = Storage(args.database)
    try:
        counts = storage.queue_counts()
        logger.info(
            "status read database=%s stores=%d queue=%s",
            args.database,
            storage.store_count(),
            counts,
        )
        print(f"Stores: {storage.store_count()}")
        if counts:
            print("Queue: " + ", ".join(f"{key}={value}" for key, value in sorted(counts.items())))
        else:
            print("Queue: empty")
        return 0
    finally:
        storage.close()


def run_sync(args: argparse.Namespace) -> int:
    storage = Storage(args.database)
    try:
        try:
            client = SyncClient(
                endpoint=args.endpoint,
                key_id=args.key_id,
                secret=secret_from_environment(args.secret_env),
                timeout=args.timeout,
                retries=args.retries,
            )
            result = sync_database(
                storage,
                client,
                batch_size=args.batch_size,
                full=args.full,
                dry_run=args.dry_run,
            )
        except (ValueError, SyncError) as error:
            logger.error("remote sync failed error=%s", error)
            print(f"Sync failed: {error}", file=sys.stderr)
            return 1

        if args.dry_run:
            print(f"Dry run: {result.stores} store(s) are ready to sync.")
        elif result.stores == 0:
            print("No new or updated stores to sync.")
        else:
            print(
                f"Sync complete: {result.stores} store(s) in {result.batches} batch(es); "
                f"{result.created} new, {result.updated} updated, "
                f"{result.technologies} app records, {result.products} products, "
                f"and {result.signals} signals upserted."
            )
        return 0
    finally:
        storage.close()


def run_menu(verbose: bool = False) -> int:
    print("Shopify Store Spider")
    print("A polite little crawler with a suspiciously useful menu.\n")

    while True:
        print("Choose an option:")
        print("  1. Discover candidates with Common Crawl")
        print("  2. Start or resume seed scan")
        print("  3. Show crawl status")
        print("  4. Export stores to CSV")
        print("  5. Add seed URLs to a seed file")
        print("  6. Sync data to ShopSignal")
        print("  7. Quit")
        choice = input("> ").strip()

        if choice == "1":
            code = run_discover(_discover_args_from_prompts(verbose=verbose))
            if code not in (0, 130):
                return code
        elif choice == "2":
            args = _scan_args_from_prompts(verbose=verbose)
            code = run_scan(args)
            if code not in (0, 130):
                return code
        elif choice == "3":
            database = _ask("Database path", "shopify_spider.sqlite3")
            run_status(argparse.Namespace(database=database))
        elif choice == "4":
            database = _ask("Database path", "shopify_spider.sqlite3")
            output = _ask("Output CSV", "stores.csv")
            run_export(argparse.Namespace(database=database, output=output))
        elif choice == "5":
            _append_seed_file()
        elif choice == "6":
            code = run_sync(_sync_args_from_prompts(verbose=verbose))
            if code != 0:
                return code
        elif choice in {"7", "q", "quit", "exit"}:
            print("Good hunting.")
            return 0
        else:
            print("Please choose 1, 2, 3, 4, 5, 6, or 7.")
        print()


def _discover_args_from_prompts(verbose: bool = False) -> argparse.Namespace:
    scan_now = _ask_yes_no("Validate discovered candidates immediately", True)
    return argparse.Namespace(
        limit=_ask_int("Maximum candidates", 500),
        query=_ask("Common Crawl URL pattern", DEFAULT_QUERY),
        collection=None,
        index_timeout=30.0,
        scan=scan_now,
        database=_ask("Database path", "shopify_spider.sqlite3"),
        output=_ask("Output CSV", "stores.csv"),
        max_pages=_ask_int("Max pages this run", 250) if scan_now else 250,
        max_domains=500,
        depth=0,
        store_depth=1,
        pages_per_host=8,
        concurrency=_ask_int("Concurrency", 8) if scan_now else 4,
        delay=_ask_float("Delay per host in seconds", 1.0) if scan_now else 1.0,
        timeout=15.0,
        user_agent=_ask("User agent", DEFAULT_UA),
        ignore_robots=False,
        no_progress=False,
        verbose=verbose,
    )


def _scan_args_from_prompts(verbose: bool = False) -> argparse.Namespace:
    return argparse.Namespace(
        seeds=_ask("Seed file", "examples/seeds.txt"),
        database=_ask("Database path", "shopify_spider.sqlite3"),
        output=_ask("Output CSV", "stores.csv"),
        max_pages=_ask_int("Max pages this run", 250),
        max_domains=_ask_int("Max discovered domains", 500),
        depth=_ask_int("Discovery depth", 2),
        store_depth=_ask_int("Confirmed store depth", 1),
        pages_per_host=_ask_int("Pages per host", 8),
        concurrency=_ask_int("Concurrency", 8),
        delay=_ask_float("Delay per host in seconds", 1.0),
        timeout=_ask_float("Timeout in seconds", 15.0),
        user_agent=_ask("User agent", DEFAULT_UA),
        ignore_robots=_ask_yes_no("Ignore robots.txt? Not recommended", False),
        no_progress=False,
        verbose=verbose,
    )


def _sync_args_from_prompts(verbose: bool = False) -> argparse.Namespace:
    return argparse.Namespace(
        database=_ask("Database path", "shopify_spider.sqlite3"),
        endpoint=_ask(
            "ShopSignal ingestion endpoint",
            os.environ.get(
                "SHOPSIGNAL_INGEST_URL", "https://onecom.io/shopsignal/api/ingest.php"
            ),
        ),
        key_id=_ask(
            "Ingestion key ID", os.environ.get("SHOPSIGNAL_INGEST_KEY_ID", "home-scraper")
        ),
        secret_env="SHOPSIGNAL_INGEST_SECRET",
        batch_size=_ask_int("Stores per batch", 100),
        timeout=30.0,
        retries=3,
        full=_ask_yes_no("Run a full sync", False),
        dry_run=False,
        verbose=verbose,
    )


def _ask(prompt: str, default: str) -> str:
    answer = input(f"{prompt} [{default}]: ").strip()
    return answer or default


def _ask_int(prompt: str, default: int) -> int:
    while True:
        answer = _ask(prompt, str(default))
        try:
            return int(answer)
        except ValueError:
            print("Please enter a whole number.")


def _ask_float(prompt: str, default: float) -> float:
    while True:
        answer = _ask(prompt, str(default))
        try:
            return float(answer)
        except ValueError:
            print("Please enter a number.")


def _ask_yes_no(prompt: str, default: bool) -> bool:
    suffix = "Y/n" if default else "y/N"
    answer = input(f"{prompt} [{suffix}]: ").strip().lower()
    if not answer:
        return default
    return answer in {"y", "yes", "true", "1"}


def _append_seed_file() -> None:
    seed_path = Path(_ask("Seed file", "seeds.txt"))
    print("Paste one URL/domain per line. Submit a blank line when done.")
    values: list[str] = []
    while True:
        value = input("seed> ").strip()
        if not value:
            break
        values.append(value)
    if not values:
        print("No seeds added.")
        return
    seed_path.parent.mkdir(parents=True, exist_ok=True)
    with seed_path.open("a", encoding="utf-8") as handle:
        for value in values:
            handle.write(value + "\n")
    print(f"Added {len(values)} seed(s) to {seed_path}.")


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        configure_logging(
            level=getattr(args, "log_level", "INFO"),
            log_file=getattr(args, "log_file", None),
            verbose=getattr(args, "verbose", False),
        )
    except (OSError, ValueError) as error:
        print(f"Unable to configure logging: {error}", file=sys.stderr)
        return 2

    command = args.command or "menu"
    logger.info("command started command=%s", command)
    try:
        if args.command in {None, "menu"}:
            code = run_menu(verbose=getattr(args, "verbose", False))
        elif args.command == "scan":
            code = run_scan(args)
        elif args.command == "discover":
            code = run_discover(args)
        elif args.command == "export":
            code = run_export(args)
        elif args.command == "status":
            code = run_status(args)
        elif args.command == "sync":
            code = run_sync(args)
        else:
            code = 2
        logger.info("command finished command=%s exit_code=%d", command, code)
        return code
    finally:
        shutdown_logging()


if __name__ == "__main__":
    raise SystemExit(main())
