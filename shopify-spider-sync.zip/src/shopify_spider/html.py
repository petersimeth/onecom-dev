from __future__ import annotations

import html as html_lib
import json
import re
from html.parser import HTMLParser

from .models import PageMetadata, ProductRecord, TechnologyRecord
from .urls import normalize_url


EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
CURRENCY_RE = re.compile(
    r'(?i)(?:currency|shopCurrency|currencyCode)["\']?\s*[:=]\s*["\']([A-Z]{3})'
)
SOCIAL_HOSTS = (
    "facebook.com",
    "instagram.com",
    "linkedin.com",
    "pinterest.com",
    "tiktok.com",
    "twitter.com",
    "x.com",
    "youtube.com",
)

TECHNOLOGY_SIGNATURES = (
    ("Klaviyo", "Email marketing", "kl", ("klaviyo.com", "klaviyo")),
    ("Judge.me", "Reviews", "jm", ("judge.me", "judgeme")),
    ("Yotpo", "Reviews & loyalty", "yo", ("yotpo.com", "staticw2.yotpo")),
    ("Gorgias", "Customer support", "go", ("gorgias.chat", "gorgias")),
    ("Recharge", "Subscriptions", "rc", ("rechargepayments.com", "rechargecdn")),
    ("Rebuy", "Upsells", "rb", ("rebuyengine.com", "rebuy")),
    ("Nosto", "Personalization", "no", ("nosto.com", "nostojs")),
    ("Okendo", "Reviews", "ok", ("okendo.io", "okendo")),
    ("Loox", "Reviews", "lx", ("loox.io", "loox")),
    ("Afterpay", "Payments", "ap", ("afterpay.com", "afterpay")),
    ("Algolia", "Site search", "al", ("algolia.net", "algoliasearch")),
    ("Loop Returns", "Returns", "lr", ("loopreturns.com", "loop-returns")),
)


class MetadataParser(HTMLParser):
    def __init__(self, page_url: str) -> None:
        super().__init__(convert_charrefs=True)
        self.page_url = page_url
        self.in_title = False
        self.title_parts: list[str] = []
        self.description = ""
        self.language = ""
        self.links: list[str] = []
        self.social_links: list[str] = []
        self.in_json_ld = False
        self.json_ld_parts: list[str] = []
        self.json_ld_blocks: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = {key.lower(): value or "" for key, value in attrs}
        tag = tag.lower()
        if tag == "html":
            self.language = values.get("lang", "").strip()
        elif tag == "title":
            self.in_title = True
        elif tag == "meta":
            name = values.get("name", "").lower()
            prop = values.get("property", "").lower()
            if name == "description" or prop == "og:description":
                self.description = self.description or values.get("content", "").strip()
        elif tag == "a":
            link = normalize_url(values.get("href", ""), self.page_url)
            if link:
                self.links.append(link)
                if any(host in link.lower() for host in SOCIAL_HOSTS):
                    self.social_links.append(link)
        elif tag == "script" and values.get("type", "").lower() == "application/ld+json":
            self.in_json_ld = True
            self.json_ld_parts = []

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "title":
            self.in_title = False
        elif tag.lower() == "script" and self.in_json_ld:
            self.json_ld_blocks.append("".join(self.json_ld_parts))
            self.json_ld_parts = []
            self.in_json_ld = False

    def handle_data(self, data: str) -> None:
        if self.in_title:
            self.title_parts.append(data)
        if self.in_json_ld:
            self.json_ld_parts.append(data)


def _json_objects(value: object):
    if isinstance(value, list):
        for item in value:
            yield from _json_objects(item)
    elif isinstance(value, dict):
        yield value
        if "@graph" in value:
            yield from _json_objects(value["@graph"])


def _product_records(blocks: list[str], page_url: str) -> list[ProductRecord]:
    products: list[ProductRecord] = []
    seen: set[str] = set()
    for block in blocks:
        try:
            data = json.loads(block)
        except (TypeError, ValueError, json.JSONDecodeError):
            continue
        for item in _json_objects(data):
            item_type = item.get("@type", "")
            types = item_type if isinstance(item_type, list) else [item_type]
            if not any(str(value).lower() == "product" for value in types):
                continue
            name = " ".join(str(item.get("name", "")).split())[:255]
            if not name:
                continue
            offers = item.get("offers", {})
            if isinstance(offers, list):
                offers = next((offer for offer in offers if isinstance(offer, dict)), {})
            if not isinstance(offers, dict):
                offers = {}
            raw_price = offers.get("price", offers.get("lowPrice", 0))
            try:
                price = max(0.0, float(str(raw_price).replace(",", "")))
            except ValueError:
                price = 0.0
            url = normalize_url(str(item.get("url") or offers.get("url") or page_url), page_url) or page_url
            key = url.lower() if "/products/" in url.lower() else name.lower()
            if key in seen:
                continue
            seen.add(key)
            category = item.get("category", "")
            if isinstance(category, list):
                category = category[0] if category else ""
            products.append(
                ProductRecord(
                    name=name,
                    category=" ".join(str(category).split())[:120],
                    price=price,
                    currency=str(offers.get("priceCurrency", ""))[:10].upper(),
                    url=url[:500],
                )
            )
    return products[:100]


def _technology_records(body: str) -> list[TechnologyRecord]:
    lowered = body.lower()
    records = []
    for name, category, short_code, signatures in TECHNOLOGY_SIGNATURES:
        if any(signature in lowered for signature in signatures):
            records.append(TechnologyRecord(name, category, short_code))
    return records


def parse_metadata(body: str, page_url: str) -> PageMetadata:
    parser = MetadataParser(page_url)
    try:
        parser.feed(body)
    except Exception:
        # Partial metadata is still useful when storefront markup is malformed.
        pass

    emails = sorted(set(EMAIL_RE.findall(html_lib.unescape(body))))[:20]
    currency_match = CURRENCY_RE.search(body)
    return PageMetadata(
        title=" ".join("".join(parser.title_parts).split())[:500],
        description=" ".join(parser.description.split())[:1000],
        language=parser.language[:50],
        currency=currency_match.group(1).upper() if currency_match else "",
        emails=emails,
        social_links=list(dict.fromkeys(parser.social_links))[:20],
        links=list(dict.fromkeys(parser.links)),
        technologies=_technology_records(body),
        products=_product_records(parser.json_ld_blocks, page_url),
    )
