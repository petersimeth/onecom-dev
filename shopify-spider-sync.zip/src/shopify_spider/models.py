from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class TechnologyRecord:
    name: str
    category: str
    short_code: str = ""


@dataclass(slots=True)
class ProductRecord:
    name: str
    category: str = ""
    price: float = 0.0
    currency: str = ""
    url: str = ""


@dataclass(slots=True)
class FetchResult:
    requested_url: str
    final_url: str
    status: int
    headers: dict[str, str]
    body: str
    error: str | None = None


@dataclass(slots=True)
class PageMetadata:
    title: str = ""
    description: str = ""
    language: str = ""
    currency: str = ""
    emails: list[str] = field(default_factory=list)
    social_links: list[str] = field(default_factory=list)
    links: list[str] = field(default_factory=list)
    technologies: list[TechnologyRecord] = field(default_factory=list)
    products: list[ProductRecord] = field(default_factory=list)


@dataclass(slots=True)
class DetectionResult:
    is_shopify: bool
    confidence: int
    signals: list[str]
    myshopify_domain: str = ""
