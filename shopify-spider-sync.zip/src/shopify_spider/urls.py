from __future__ import annotations

import ipaddress
import posixpath
import re
from urllib.parse import urljoin, urlsplit, urlunsplit


IGNORED_HOSTS = {
    "amazon.com",
    "apple.com",
    "discord.com",
    "facebook.com",
    "github.com",
    "google.com",
    "instagram.com",
    "linkedin.com",
    "pinterest.com",
    "reddit.com",
    "tiktok.com",
    "twitter.com",
    "vimeo.com",
    "x.com",
    "youtube.com",
}

TRACKING_PARAMS = {
    "fbclid",
    "gclid",
    "mc_cid",
    "mc_eid",
    "ref",
    "source",
}


def normalize_url(value: str, base: str | None = None) -> str | None:
    value = value.strip()
    if not value or value.startswith(("#", "mailto:", "tel:", "javascript:", "data:")):
        return None
    if base:
        value = urljoin(base, value)
    elif "://" not in value:
        value = f"https://{value}"

    parts = urlsplit(value)
    if parts.scheme.lower() not in {"http", "https"} or not parts.hostname:
        return None

    host = parts.hostname.lower().rstrip(".")
    if any(character.isspace() for character in host):
        return None
    try:
        port = parts.port
    except ValueError:
        return None
    if port and not (
        (parts.scheme.lower() == "http" and port == 80)
        or (parts.scheme.lower() == "https" and port == 443)
    ):
        netloc = f"{host}:{port}"
    else:
        netloc = host

    path = re.sub(r"/{2,}", "/", parts.path or "/")
    path = posixpath.normpath(path)
    if not path.startswith("/"):
        path = "/" + path
    if parts.path.endswith("/") and not path.endswith("/"):
        path += "/"

    # Queries are intentionally dropped for the MVP to avoid crawler traps.
    return urlunsplit((parts.scheme.lower(), netloc, path, "", ""))


def origin(url: str) -> str:
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc, "", "", ""))


def host_for(url: str) -> str:
    return (urlsplit(url).hostname or "").lower()


def registrable_hint(host: str) -> str:
    """Return a conservative domain hint without relying on a public suffix package."""
    host = host.lower().lstrip("www.")
    labels = host.split(".")
    if len(labels) <= 2:
        return host
    if labels[-2] in {"co", "com", "net", "org"} and len(labels[-1]) == 2:
        return ".".join(labels[-3:])
    return ".".join(labels[-2:])


def same_site(left: str, right: str) -> bool:
    return registrable_hint(host_for(left)) == registrable_hint(host_for(right))


def is_public_candidate(url: str) -> bool:
    host = host_for(url)
    if not host or host == "localhost" or host.endswith(".local"):
        return False
    try:
        address = ipaddress.ip_address(host)
        return address.is_global
    except ValueError:
        pass
    base = registrable_hint(host)
    return base not in IGNORED_HOSTS


def homepage_for(url: str) -> str:
    return origin(url) + "/"


def is_useful_store_path(url: str) -> bool:
    path = urlsplit(url).path.lower()
    blocked = (
        "/account",
        "/admin",
        "/cart",
        "/checkout",
        "/checkouts",
        "/search",
    )
    if any(path.startswith(prefix) for prefix in blocked):
        return False
    useful = ("/products/", "/collections/", "/pages/", "/blogs/")
    return path == "/" or any(path.startswith(prefix) for prefix in useful)
