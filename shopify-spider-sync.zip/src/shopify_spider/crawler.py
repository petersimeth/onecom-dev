from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .detector import detect_shopify
from .fetcher import PoliteFetcher
from .html import parse_metadata
from .storage import Storage
from .urls import (
    homepage_for,
    host_for,
    is_public_candidate,
    is_useful_store_path,
    normalize_url,
    same_site,
)


logger = logging.getLogger(__name__)


@dataclass(slots=True)
class CrawlConfig:
    max_pages: int = 250
    max_domains: int = 500
    discovery_depth: int = 2
    store_depth: int = 1
    pages_per_host: int = 8
    concurrency: int = 4


@dataclass(frozen=True, slots=True)
class CrawlProgress:
    processed: int
    max_pages: int
    stores_found: int
    queue_counts: dict[str, int]
    current_url: str = ""
    message: str = ""


ProgressCallback = Callable[[CrawlProgress], None]


class Spider:
    def __init__(self, storage: Storage, fetcher: PoliteFetcher, config: CrawlConfig) -> None:
        self.storage = storage
        self.fetcher = fetcher
        self.config = config
        self.pages_processed = 0
        self.domains_seen: set[str] = set()
        self.host_page_counts: dict[str, int] = {}
        self._db_lock = asyncio.Lock()
        self._ready_items: list[dict[str, object]] = []
        self._scheduled_pages = 0
        self._active_pages = 0
        self._progress_callback: ProgressCallback | None = None

    def add_seeds(self, values: list[str]) -> int:
        rows: list[tuple[str, str | None, int, str]] = []
        for value in values:
            url = normalize_url(value)
            if url:
                rows.append((url, None, 0, "discovery"))
        added = self.storage.enqueue_many(rows)
        logger.debug(
            "seeds normalized input=%d valid=%d added=%d", len(values), len(rows), added
        )
        return added

    async def run(self, progress_callback: ProgressCallback | None = None) -> None:
        started = time.monotonic()
        self._progress_callback = progress_callback
        self._ready_items = []
        self._scheduled_pages = 0
        self._active_pages = 0
        self.storage.reset_running()
        worker_count = max(1, min(self.config.concurrency, self.config.max_pages))
        logger.info(
            "crawl started workers=%d max_pages=%d max_domains=%d pages_per_host=%d",
            worker_count,
            self.config.max_pages,
            self.config.max_domains,
            self.config.pages_per_host,
        )
        await self._emit_progress(message="Starting crawl")
        try:
            await asyncio.gather(*(self._worker(index + 1) for index in range(worker_count)))
        except Exception:
            logger.exception("crawl aborted processed=%d", self.pages_processed)
            raise
        await self._emit_progress(message="Crawl finished")
        logger.info(
            "crawl finished processed=%d stores=%d elapsed_seconds=%.3f",
            self.pages_processed,
            self.storage.store_count(),
            time.monotonic() - started,
        )

    async def _worker(self, worker_id: int) -> None:
        logger.debug("worker started worker=%d", worker_id)
        while True:
            async with self._db_lock:
                if self._scheduled_pages >= self.config.max_pages:
                    logger.debug("worker stopped worker=%d reason=max_pages", worker_id)
                    return
                if not self._ready_items:
                    remaining = self.config.max_pages - self._scheduled_pages
                    batch_size = max(1, min(self.config.concurrency, remaining))
                    self._ready_items = [
                        dict(row) for row in self.storage.next_pending_batch(batch_size)
                    ]
                if not self._ready_items:
                    if self._active_pages > 0:
                        wait_for_more = True
                    else:
                        logger.debug("worker stopped worker=%d reason=queue_empty", worker_id)
                        return
                else:
                    wait_for_more = False
                    row = self._ready_items.pop(0)
                    self._scheduled_pages += 1
                    self._active_pages += 1
            if wait_for_more:
                await asyncio.sleep(0.1)
                continue
            try:
                await self._process(row, worker_id)
            finally:
                async with self._db_lock:
                    self._active_pages -= 1

    async def _process(self, item: dict[str, object], worker_id: int = 1) -> None:
        url = str(item["url"])
        source_url = str(item["source_url"]) if item["source_url"] else None
        depth = int(item["depth"])
        kind = str(item["kind"])
        host = host_for(url)

        async with self._db_lock:
            host_pages = self.host_page_counts.get(host, 0)
            if host_pages >= self.config.pages_per_host:
                with self.storage.transaction():
                    self.storage.finish(url, "per-host page limit reached", commit=False)
                    self.pages_processed += 1
                logger.info("page skipped reason=per_host_limit worker=%d url=%s", worker_id, url)
                await self._emit_progress_unlocked(
                    current_url=url,
                    message=f"worker {worker_id}: skipped per-host limit",
                )
                return
            self.host_page_counts[host] = host_pages + 1

        await self._emit_progress(current_url=url, message=f"worker {worker_id}: fetching")
        logger.debug(
            "page fetch started worker=%d kind=%s depth=%d url=%s",
            worker_id,
            kind,
            depth,
            url,
        )
        result = await self.fetcher.fetch(url)

        if result.error or result.status < 200 or result.status >= 400 or not result.body:
            async with self._db_lock:
                with self.storage.transaction():
                    self.pages_processed += 1
                    self.storage.finish(url, result.error or f"HTTP {result.status}", commit=False)
                logger.warning(
                    "page fetch failed worker=%d status=%d error=%s url=%s",
                    worker_id,
                    result.status,
                    result.error or "empty or unsupported response",
                    url,
                )
                await self._emit_progress_unlocked(
                    current_url=url,
                    message=f"worker {worker_id}: failed",
                )
            return

        final_url = normalize_url(result.final_url) or url
        metadata = parse_metadata(result.body, final_url)
        detection = detect_shopify(result.body, result.headers)
        final_host = host_for(final_url)

        async with self._db_lock:
            with self.storage.transaction():
                self.pages_processed += 1
                self.domains_seen.add(final_host)
                if detection.is_shopify:
                    store_created = self.storage.save_store(
                        final_host,
                        url,
                        final_url,
                        metadata,
                        detection,
                        source_url,
                        commit=False,
                    )
                    intelligence_counts = self.storage.save_intelligence(
                        final_host,
                        metadata,
                        store_created=store_created,
                        commit=False,
                    )
                    self.storage.save_page(
                        final_url, final_host, result.status, metadata.title, commit=False
                    )

                discovery_rows, queue_rows = self._collect_links(
                    current_url=final_url,
                    links=metadata.links,
                    depth=depth,
                    kind="store" if detection.is_shopify or kind == "store" else kind,
                )
                self.storage.save_discoveries_many(discovery_rows, commit=False)
                self.storage.enqueue_many(queue_rows, commit=False)
                self.storage.finish(url, commit=False)
            if detection.is_shopify:
                logger.info(
                    "Shopify store detected domain=%s confidence=%d signals=%s technologies=%d products=%d changes=%d source=%s",
                    final_host,
                    detection.confidence,
                    ",".join(detection.signals),
                    intelligence_counts["technologies"],
                    intelligence_counts["products"],
                    intelligence_counts["signals"],
                    source_url or "direct",
                )
            logger.debug(
                "page processed worker=%d status=%d shopify=%s discoveries=%d queued=%d url=%s",
                worker_id,
                result.status,
                detection.is_shopify,
                len(discovery_rows),
                len(queue_rows),
                final_url,
            )
            status = "store found" if detection.is_shopify else "processed"
            await self._emit_progress_unlocked(
                current_url=final_url,
                message=f"worker {worker_id}: {status}",
            )

    async def _emit_progress(self, current_url: str = "", message: str = "") -> None:
        if self._progress_callback is None:
            return
        async with self._db_lock:
            await self._emit_progress_unlocked(current_url, message)

    async def _emit_progress_unlocked(self, current_url: str = "", message: str = "") -> None:
        if self._progress_callback is None:
            return
        self._progress_callback(
            CrawlProgress(
                processed=self.pages_processed,
                max_pages=self.config.max_pages,
                stores_found=self.storage.store_count(),
                queue_counts=self.storage.queue_counts(),
                current_url=current_url,
                message=message,
            )
        )

    def _collect_links(
        self, current_url: str, links: list[str], depth: int, kind: str
    ) -> tuple[list[tuple[str, str, str]], list[tuple[str, str | None, int, str]]]:
        discovery_rows: list[tuple[str, str, str]] = []
        queue_rows: list[tuple[str, str | None, int, str]] = []
        for link in links:
            if len(self.domains_seen) >= self.config.max_domains:
                return discovery_rows, queue_rows
            if same_site(current_url, link):
                if kind == "store":
                    if depth < self.config.store_depth and is_useful_store_path(link):
                        queue_rows.append((link, current_url, depth + 1, "store"))
                elif depth < self.config.discovery_depth:
                    queue_rows.append((link, current_url, depth + 1, "discovery"))
                continue

            if not is_public_candidate(link):
                continue
            candidate = homepage_for(link)
            target_host = host_for(candidate)
            self.domains_seen.add(target_host)
            discovery_rows.append((current_url, candidate, target_host))
            queue_rows.append((candidate, current_url, 0, "candidate"))
        return discovery_rows, queue_rows


def read_seeds(path: str | Path) -> list[str]:
    values = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            values.append(line.split(",")[0].strip())
    return values
