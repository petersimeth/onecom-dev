from __future__ import annotations

import re

from .models import DetectionResult


MYSHOPIFY_RE = re.compile(r"(?i)\b([a-z0-9][a-z0-9-]*\.myshopify\.com)\b")


SIGNALS: tuple[tuple[str, re.Pattern[str], int], ...] = (
    ("Shopify generator meta tag", re.compile(r'(?i)generator[^>]+content=["\']Shopify'), 55),
    ("Shopify global object", re.compile(r"(?i)\bShopify\.(?:shop|theme|routes|currency)\b"), 35),
    ("Shopify CDN shop asset", re.compile(r"(?i)(?:cdn\.shopify\.com|/cdn/shop/)"), 35),
    ("myshopify.com reference", MYSHOPIFY_RE, 35),
    ("Shopify section markup", re.compile(r"(?i)(?:shopify-section|data-shopify)"), 20),
    ("Shopify analytics", re.compile(r"(?i)(?:ShopifyAnalytics|shopifycloud)"), 25),
    ("Shopify storefront route", re.compile(r"(?i)/(?:products|collections)/[^\"'<>\s]+"), 8),
)


def detect_shopify(body: str, headers: dict[str, str] | None = None) -> DetectionResult:
    score = 0
    found: list[str] = []
    for label, pattern, weight in SIGNALS:
        if pattern.search(body):
            score += weight
            found.append(label)

    normalized_headers = {key.lower(): value for key, value in (headers or {}).items()}
    if "x-shopid" in normalized_headers:
        score += 55
        found.append("Shopify X-ShopId response header")
    if "x-sorting-hat-podid" in normalized_headers:
        score += 30
        found.append("Shopify sorting-hat response header")
    if "_shopify_" in normalized_headers.get("set-cookie", "").lower():
        score += 20
        found.append("Shopify cookie")

    match = MYSHOPIFY_RE.search(body)
    confidence = min(score, 100)
    return DetectionResult(
        is_shopify=confidence >= 50,
        confidence=confidence,
        signals=found,
        myshopify_domain=match.group(1).lower() if match else "",
    )
