from __future__ import annotations

import csv
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import logging
import sqlite3
from pathlib import Path
from typing import Iterable, Iterator

from .models import DetectionResult, PageMetadata


logger = logging.getLogger(__name__)


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA temp_store=MEMORY;

CREATE TABLE IF NOT EXISTS queue (
    url TEXT PRIMARY KEY,
    source_url TEXT,
    depth INTEGER NOT NULL DEFAULT 0,
    kind TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    error TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS queue_status_idx ON queue(status, created_at);

CREATE TABLE IF NOT EXISTS stores (
    domain TEXT PRIMARY KEY,
    url TEXT NOT NULL,
    final_url TEXT NOT NULL,
    title TEXT,
    description TEXT,
    language TEXT,
    currency TEXT,
    emails TEXT NOT NULL DEFAULT '[]',
    social_links TEXT NOT NULL DEFAULT '[]',
    confidence INTEGER NOT NULL,
    signals TEXT NOT NULL DEFAULT '[]',
    myshopify_domain TEXT,
    discovered_from TEXT,
    first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS discoveries (
    source_url TEXT NOT NULL,
    target_url TEXT NOT NULL,
    target_domain TEXT NOT NULL,
    discovered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (source_url, target_url)
);

CREATE TABLE IF NOT EXISTS pages (
    url TEXT PRIMARY KEY,
    store_domain TEXT NOT NULL,
    status_code INTEGER NOT NULL,
    title TEXT,
    crawled_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS technologies (
    store_domain TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    short_code TEXT NOT NULL DEFAULT '',
    first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (store_domain, name)
);

CREATE TABLE IF NOT EXISTS products (
    store_domain TEXT NOT NULL,
    source_key TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT '',
    price REAL NOT NULL DEFAULT 0,
    currency TEXT NOT NULL DEFAULT '',
    url TEXT NOT NULL DEFAULT '',
    first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (store_domain, source_key)
);

CREATE TABLE IF NOT EXISTS store_signals (
    store_domain TEXT NOT NULL,
    source_key TEXT NOT NULL,
    signal_type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    occurred_label TEXT NOT NULL DEFAULT 'Recently',
    PRIMARY KEY (store_domain, source_key)
);

CREATE TABLE IF NOT EXISTS sync_state (
    state_key TEXT PRIMARY KEY,
    state_value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS technology_store_idx ON technologies(store_domain, last_seen_at);
CREATE INDEX IF NOT EXISTS product_store_idx ON products(store_domain, last_seen_at);
CREATE INDEX IF NOT EXISTS store_signal_store_idx ON store_signals(store_domain, occurred_at);
"""


class Storage:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.connection = sqlite3.connect(self.path)
        self.connection.row_factory = sqlite3.Row
        self.connection.executescript(SCHEMA)
        logger.debug("database opened path=%s", self.path)

    def close(self) -> None:
        self.connection.close()
        logger.debug("database closed path=%s", self.path)

    @contextmanager
    def transaction(self) -> Iterator[None]:
        try:
            yield
        except Exception:
            self.connection.rollback()
            logger.exception("database transaction rolled back path=%s", self.path)
            raise
        else:
            self.connection.commit()

    def reset_running(self) -> None:
        cursor = self.connection.execute(
            "UPDATE queue SET status = 'pending', updated_at = CURRENT_TIMESTAMP "
            "WHERE status = 'running'"
        )
        self.connection.commit()
        if cursor.rowcount:
            logger.info("crawl queue resumed reset_running=%d", cursor.rowcount)

    def enqueue(self, url: str, source_url: str | None, depth: int, kind: str) -> bool:
        cursor = self.connection.execute(
            "INSERT OR IGNORE INTO queue(url, source_url, depth, kind) VALUES (?, ?, ?, ?)",
            (url, source_url, depth, kind),
        )
        self.connection.commit()
        return cursor.rowcount > 0

    def next_pending(self) -> sqlite3.Row | None:
        row = self.connection.execute(
            "SELECT * FROM queue WHERE status = 'pending' ORDER BY created_at, rowid LIMIT 1"
        ).fetchone()
        if row:
            self.connection.execute(
                "UPDATE queue SET status = 'running', updated_at = CURRENT_TIMESTAMP WHERE url = ?",
                (row["url"],),
            )
            self.connection.commit()
        return row

    def next_pending_batch(self, limit: int) -> list[sqlite3.Row]:
        if limit <= 0:
            return []
        rows = self.connection.execute(
            "SELECT * FROM queue WHERE status = 'pending' ORDER BY created_at, rowid LIMIT ?",
            (limit,),
        ).fetchall()
        if not rows:
            return []
        self.connection.executemany(
            "UPDATE queue SET status = 'running', updated_at = CURRENT_TIMESTAMP WHERE url = ?",
            [(row["url"],) for row in rows],
        )
        self.connection.commit()
        logger.debug("queue batch claimed requested=%d claimed=%d", limit, len(rows))
        return list(rows)

    def finish(self, url: str, error: str | None = None, commit: bool = True) -> None:
        self.connection.execute(
            "UPDATE queue SET status = ?, error = ?, updated_at = CURRENT_TIMESTAMP WHERE url = ?",
            ("failed" if error else "done", error, url),
        )
        if commit:
            self.connection.commit()

    def save_discovery(
        self, source_url: str, target_url: str, target_domain: str, commit: bool = True
    ) -> None:
        self.connection.execute(
            "INSERT OR IGNORE INTO discoveries(source_url, target_url, target_domain) "
            "VALUES (?, ?, ?)",
            (source_url, target_url, target_domain),
        )
        if commit:
            self.connection.commit()

    def save_intelligence(
        self,
        domain: str,
        metadata: PageMetadata,
        store_created: bool,
        commit: bool = True,
    ) -> dict[str, int]:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        counts = {"technologies": 0, "products": 0, "signals": 0}

        if store_created:
            counts["signals"] += self._save_signal(
                domain,
                "store_discovered",
                "discovery",
                "Shopify store discovered",
                "The storefront was confirmed through multiple public Shopify signals.",
                now,
                "Just detected",
            )

        for technology in metadata.technologies:
            cursor = self.connection.execute(
                "INSERT OR IGNORE INTO technologies(store_domain, name, category, short_code, first_seen_at, last_seen_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (domain, technology.name, technology.category, technology.short_code, now, now),
            )
            is_new = cursor.rowcount > 0
            self.connection.execute(
                "UPDATE technologies SET category = ?, short_code = ?, last_seen_at = ? "
                "WHERE store_domain = ? AND name = ?",
                (technology.category, technology.short_code, now, domain, technology.name),
            )
            counts["technologies"] += 1
            if is_new and not store_created:
                counts["signals"] += self._save_signal(
                    domain,
                    "technology:" + technology.name.lower(),
                    "technology",
                    "New technology detected",
                    f"{technology.name} was detected on the public storefront.",
                    now,
                    "Just detected",
                )

        for product in metadata.products:
            key_material = product.url.lower() or f"{product.name.lower()}|{product.category.lower()}"
            source_key = hashlib.sha256(key_material.encode("utf-8")).hexdigest()
            cursor = self.connection.execute(
                "INSERT OR IGNORE INTO products(store_domain, source_key, name, category, price, currency, url, first_seen_at, last_seen_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    domain,
                    source_key,
                    product.name,
                    product.category,
                    product.price,
                    product.currency,
                    product.url,
                    now,
                    now,
                ),
            )
            is_new = cursor.rowcount > 0
            self.connection.execute(
                "UPDATE products SET name = ?, category = ?, price = ?, currency = ?, url = ?, last_seen_at = ? "
                "WHERE store_domain = ? AND source_key = ?",
                (
                    product.name,
                    product.category,
                    product.price,
                    product.currency,
                    product.url,
                    now,
                    domain,
                    source_key,
                ),
            )
            counts["products"] += 1
            if is_new and not store_created:
                counts["signals"] += self._save_signal(
                    domain,
                    "product:" + source_key,
                    "product",
                    "New product detected",
                    f"{product.name} appeared in the public storefront catalog.",
                    now,
                    "Just detected",
                )

        if commit:
            self.connection.commit()
        return counts

    def _save_signal(
        self,
        domain: str,
        source_key: str,
        signal_type: str,
        title: str,
        description: str,
        occurred_at: str,
        occurred_label: str,
    ) -> int:
        cursor = self.connection.execute(
            "INSERT OR IGNORE INTO store_signals(store_domain, source_key, signal_type, title, description, occurred_at, occurred_label) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (domain, source_key, signal_type, title, description, occurred_at, occurred_label),
        )
        return max(0, cursor.rowcount)

    def records_for_sync(self, since: str | None = None) -> list[dict[str, object]]:
        if since:
            rows = self.connection.execute(
                "SELECT * FROM stores WHERE last_seen_at > ? ORDER BY domain", (since,)
            ).fetchall()
        else:
            rows = self.connection.execute("SELECT * FROM stores ORDER BY domain").fetchall()

        records: list[dict[str, object]] = []
        for row in rows:
            domain = str(row["domain"])
            technologies = self.connection.execute(
                "SELECT name, category, short_code, first_seen_at AS detected_at, last_seen_at "
                "FROM technologies WHERE store_domain = ? ORDER BY name",
                (domain,),
            ).fetchall()
            products = self.connection.execute(
                "SELECT name, category, price, currency, url, first_seen_at, last_seen_at "
                "FROM products WHERE store_domain = ? ORDER BY last_seen_at DESC, name LIMIT 200",
                (domain,),
            ).fetchall()
            signals = self.connection.execute(
                "SELECT signal_type AS type, title, description, occurred_at, occurred_label "
                "FROM store_signals WHERE store_domain = ? ORDER BY occurred_at DESC LIMIT 200",
                (domain,),
            ).fetchall()
            records.append(
                {
                    "domain": domain,
                    "url": row["url"],
                    "final_url": row["final_url"],
                    "name": row["title"] or domain.split(".")[0].replace("-", " ").title(),
                    "description": row["description"] or "",
                    "language": row["language"] or "",
                    "currency": row["currency"] or "",
                    "emails": self._json_list(row["emails"]),
                    "social_links": self._json_list(row["social_links"]),
                    "confidence": int(row["confidence"]),
                    "detection_signals": self._json_list(row["signals"]),
                    "myshopify_domain": row["myshopify_domain"] or "",
                    "discovered_from": row["discovered_from"] or "",
                    "first_seen_at": row["first_seen_at"],
                    "last_seen_at": row["last_seen_at"],
                    "technologies": [dict(item) for item in technologies],
                    "products": [dict(item) for item in products],
                    "signals": [dict(item) for item in signals],
                }
            )
        return records

    def get_sync_cursor(self) -> str | None:
        row = self.connection.execute(
            "SELECT state_value FROM sync_state WHERE state_key = 'remote_cursor'"
        ).fetchone()
        return str(row[0]) if row else None

    def set_sync_cursor(self, value: str) -> None:
        self.connection.execute(
            "INSERT INTO sync_state(state_key, state_value) VALUES ('remote_cursor', ?) "
            "ON CONFLICT(state_key) DO UPDATE SET state_value = excluded.state_value, updated_at = CURRENT_TIMESTAMP",
            (value,),
        )
        self.connection.commit()

    @staticmethod
    def _json_list(value: object) -> list[str]:
        try:
            decoded = json.loads(str(value or "[]"))
        except (TypeError, ValueError, json.JSONDecodeError):
            return []
        return [str(item) for item in decoded] if isinstance(decoded, list) else []

    def save_discoveries_many(
        self, rows: Iterable[tuple[str, str, str]], commit: bool = True
    ) -> int:
        values = list(rows)
        if not values:
            return 0
        cursor = self.connection.executemany(
            "INSERT OR IGNORE INTO discoveries(source_url, target_url, target_domain) "
            "VALUES (?, ?, ?)",
            values,
        )
        if commit:
            self.connection.commit()
        logger.debug("discovery batch saved requested=%d added=%d", len(values), cursor.rowcount)
        return cursor.rowcount

    def save_store(
        self,
        domain: str,
        requested_url: str,
        final_url: str,
        metadata: PageMetadata,
        detection: DetectionResult,
        discovered_from: str | None,
        commit: bool = True,
    ) -> bool:
        existed = self.connection.execute(
            "SELECT 1 FROM stores WHERE domain = ? LIMIT 1", (domain,)
        ).fetchone() is not None
        values = (
            domain,
            requested_url,
            final_url,
            metadata.title,
            metadata.description,
            metadata.language,
            metadata.currency,
            json.dumps(metadata.emails),
            json.dumps(metadata.social_links),
            detection.confidence,
            json.dumps(detection.signals),
            detection.myshopify_domain,
            discovered_from,
        )
        self.connection.execute(
            """
            INSERT INTO stores(
                domain, url, final_url, title, description, language, currency,
                emails, social_links, confidence, signals, myshopify_domain,
                discovered_from
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(domain) DO UPDATE SET
                final_url = excluded.final_url,
                title = CASE WHEN stores.title = '' AND excluded.title != '' THEN excluded.title ELSE stores.title END,
                description = CASE WHEN stores.description = '' AND excluded.description != '' THEN excluded.description ELSE stores.description END,
                language = CASE WHEN excluded.language != '' THEN excluded.language ELSE stores.language END,
                currency = CASE WHEN excluded.currency != '' THEN excluded.currency ELSE stores.currency END,
                emails = excluded.emails,
                social_links = excluded.social_links,
                confidence = MAX(stores.confidence, excluded.confidence),
                signals = excluded.signals,
                myshopify_domain = CASE
                    WHEN excluded.myshopify_domain != '' THEN excluded.myshopify_domain
                    ELSE stores.myshopify_domain
                END,
                last_seen_at = CURRENT_TIMESTAMP
            """,
            values,
        )
        logger.debug(
            "store write staged domain=%s confidence=%d discovered_from=%s",
            domain,
            detection.confidence,
            discovered_from or "direct",
        )
        if commit:
            self.connection.commit()
        return not existed

    def save_page(
        self, url: str, domain: str, status: int, title: str, commit: bool = True
    ) -> None:
        self.connection.execute(
            "INSERT OR REPLACE INTO pages(url, store_domain, status_code, title) VALUES (?, ?, ?, ?)",
            (url, domain, status, title),
        )
        if commit:
            self.connection.commit()

    def store_count(self) -> int:
        return int(self.connection.execute("SELECT COUNT(*) FROM stores").fetchone()[0])

    def queue_counts(self) -> dict[str, int]:
        rows = self.connection.execute(
            "SELECT status, COUNT(*) AS count FROM queue GROUP BY status"
        ).fetchall()
        return {row["status"]: row["count"] for row in rows}

    def export_csv(self, output: str | Path) -> int:
        rows = self.connection.execute("SELECT * FROM stores ORDER BY confidence DESC, domain").fetchall()
        fields = [
            "domain",
            "url",
            "final_url",
            "title",
            "description",
            "language",
            "currency",
            "emails",
            "social_links",
            "confidence",
            "signals",
            "myshopify_domain",
            "discovered_from",
            "first_seen_at",
            "last_seen_at",
        ]
        with Path(output).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                writer.writerow({field: row[field] for field in fields})
        logger.info("stores exported count=%d output=%s", len(rows), output)
        return len(rows)

    def enqueue_many(
        self, rows: Iterable[tuple[str, str | None, int, str]], commit: bool = True
    ) -> int:
        values = list(rows)
        if not values:
            return 0
        cursor = self.connection.executemany(
            "INSERT OR IGNORE INTO queue(url, source_url, depth, kind) VALUES (?, ?, ?, ?)",
            values,
        )
        if commit:
            self.connection.commit()
        logger.debug("queue batch inserted requested=%d added=%d", len(values), cursor.rowcount)
        return cursor.rowcount
