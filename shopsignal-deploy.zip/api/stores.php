<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/src/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$data = loadShopSignalData();

echo json_encode(
    [
        'data' => $data['stores'],
        'profiles' => $data['profiles'],
        'meta' => [
            'source' => $data['source'],
            'stats' => $data['stats'],
        ],
    ],
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);
