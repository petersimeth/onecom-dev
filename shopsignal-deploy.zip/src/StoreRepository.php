<?php
declare(strict_types=1);

final class StoreRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function findStores(
        string $search = '',
        string $sort = 'growth',
        int $limit = 50,
        int $offset = 0
    ): array {
        $sortColumns = [
            'growth' => 's.growth_percent DESC',
            'revenue' => 's.estimated_monthly_revenue DESC',
            'traffic' => 's.monthly_traffic DESC',
            'newest' => 's.founded_year DESC',
        ];
        $orderBy = $sortColumns[$sort] ?? $sortColumns['growth'];
        $limit = max(1, min($limit, 250));
        $offset = max(0, $offset);

        $sql = '
            SELECT
                s.id,
                s.name,
                s.domain,
                s.category,
                s.estimated_monthly_revenue AS revenue,
                s.monthly_traffic AS traffic,
                s.growth_percent AS growth,
                s.growth_signal AS signal,
                s.founded_year AS founded,
                s.product_count AS products,
                s.logo_class,
                s.logo_letter,
                GROUP_CONCAT(
                    DISTINCT st.short_code
                    ORDER BY st.id
                    SEPARATOR \',\'
                ) AS stack
            FROM stores s
            LEFT JOIN store_technologies st ON st.store_id = s.id
            WHERE (
                :search = \'\'
                OR s.name LIKE :search_name
                OR s.domain LIKE :search_domain
                OR s.category LIKE :search_category
            )
            GROUP BY s.id
            ORDER BY ' . $orderBy . '
            LIMIT :limit OFFSET :offset
        ';

        $statement = $this->pdo->prepare($sql);
        $statement->bindValue(':search', $search);
        $statement->bindValue(':search_name', '%' . $search . '%');
        $statement->bindValue(':search_domain', '%' . $search . '%');
        $statement->bindValue(':search_category', '%' . $search . '%');
        $statement->bindValue(':limit', $limit, PDO::PARAM_INT);
        $statement->bindValue(':offset', $offset, PDO::PARAM_INT);
        $statement->execute();

        return array_map([$this, 'formatStore'], $statement->fetchAll());
    }

    /**
     * @param array<int, array<string, mixed>> $stores
     * @return array<string, array<string, mixed>>
     */
    public function findProfilesForStores(array $stores): array
    {
        $profiles = [];

        foreach ($stores as $store) {
            $profiles[$store['name']] = $this->findProfile((int) $store['id']);
        }

        return $profiles;
    }

    /**
     * @return array<string, mixed>
     */
    private function findProfile(int $storeId): array
    {
        $statement = $this->pdo->prepare('
            SELECT
                headquarters AS location,
                country,
                employee_range AS employees,
                public_email AS email,
                public_phone AS phone,
                store_language AS language,
                currency,
                average_price,
                monthly_orders,
                conversion_rate,
                social_total,
                instagram_followers,
                tiktok_followers,
                facebook_followers
            FROM stores
            WHERE id = :id
        ');
        $statement->execute(['id' => $storeId]);
        $profile = $statement->fetch() ?: [];

        $profile['avgPrice'] = $this->formatMoney((float) ($profile['average_price'] ?? 0));
        $profile['orders'] = $this->formatCompactNumber((int) ($profile['monthly_orders'] ?? 0));
        $profile['conversion'] = number_format((float) ($profile['conversion_rate'] ?? 0), 1) . '%';
        $profile['social'] = $this->formatCompactNumber((int) ($profile['social_total'] ?? 0));
        $profile['instagram'] = $this->formatCompactNumber((int) ($profile['instagram_followers'] ?? 0));
        $profile['tiktok'] = $this->formatCompactNumber((int) ($profile['tiktok_followers'] ?? 0));
        $profile['facebook'] = $this->formatCompactNumber((int) ($profile['facebook_followers'] ?? 0));
        $profile['apps'] = $this->fetchRows(
            'SELECT technology_name, category, DATE_FORMAT(detected_at, \'%b %Y\') FROM store_technologies WHERE store_id = :store_id ORDER BY detected_at DESC',
            $storeId
        );
        $profile['products'] = $this->fetchRows(
            'SELECT name, category, CONCAT(currency_symbol, FORMAT(price, 0)) FROM products WHERE store_id = :store_id ORDER BY is_top_product DESC, id DESC LIMIT 10',
            $storeId
        );
        $profile['signals'] = $this->fetchRows(
            'SELECT occurred_label, title, description FROM store_signals WHERE store_id = :store_id ORDER BY occurred_at DESC LIMIT 10',
            $storeId
        );

        return $profile;
    }

    /**
     * @return array<string, int|string>
     */
    public function getDashboardStats(): array
    {
        $row = $this->pdo->query('
            SELECT
                COUNT(*) AS matching_stores,
                SUM(created_at >= CURRENT_DATE - INTERVAL 7 DAY) AS new_this_week,
                SUM(growth_percent >= 10) AS high_growth_stores,
                SUM(updated_at >= CURRENT_DATE - INTERVAL 7 DAY) AS updated_stores,
                AVG(estimated_monthly_revenue) AS average_revenue
            FROM stores
        ')->fetch() ?: [];

        return [
            'matching_stores' => (int) ($row['matching_stores'] ?? 0),
            'new_this_week' => (int) ($row['new_this_week'] ?? 0),
            'median_revenue' => $this->formatCompactMoney((float) ($row['average_revenue'] ?? 0)),
            'high_growth_stores' => (int) ($row['high_growth_stores'] ?? 0),
            'updated_stores' => (int) ($row['updated_stores'] ?? 0),
        ];
    }

    /**
     * @return array<int, array<int, string>>
     */
    private function fetchRows(string $sql, int $storeId): array
    {
        $statement = $this->pdo->prepare($sql);
        $statement->execute(['store_id' => $storeId]);
        return array_map('array_values', $statement->fetchAll());
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function formatStore(array $row): array
    {
        $stack = array_values(array_filter(explode(',', (string) ($row['stack'] ?? ''))));

        return [
            'id' => (int) $row['id'],
            'name' => (string) $row['name'],
            'domain' => (string) $row['domain'],
            'category' => (string) $row['category'],
            'revenue' => (float) $row['revenue'],
            'revenueLabel' => $this->formatCompactMoney((float) $row['revenue']),
            'traffic' => (int) $row['traffic'],
            'trafficLabel' => $this->formatCompactNumber((int) $row['traffic']),
            'growth' => (float) $row['growth'],
            'signal' => (string) $row['signal'],
            'logo' => (string) ($row['logo_letter'] ?: mb_substr((string) $row['name'], 0, 1)),
            'logoClass' => (string) ($row['logo_class'] ?: 'logo-allbirds'),
            'stack' => $stack,
            'founded' => (string) $row['founded'],
            'products' => number_format((int) $row['products']),
        ];
    }

    private function formatMoney(float $amount): string
    {
        return '$' . number_format($amount, $amount === floor($amount) ? 0 : 2);
    }

    private function formatCompactMoney(float $amount): string
    {
        return '$' . $this->formatCompactNumber((int) $amount);
    }

    private function formatCompactNumber(int $number): string
    {
        if ($number >= 1_000_000) {
            return rtrim(rtrim(number_format($number / 1_000_000, 1), '0'), '.') . 'M';
        }
        if ($number >= 1_000) {
            return rtrim(rtrim(number_format($number / 1_000, 1), '0'), '.') . 'K';
        }
        return number_format($number);
    }
}
