<?php
declare(strict_types=1);

require_once __DIR__ . '/src/bootstrap.php';

$shopSignalData = loadShopSignalData();
$databaseConnected = $shopSignalData['source'] === 'database';
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
      name="description"
      content="ShopSignal — a modern Shopify store intelligence dashboard mockup."
    />
    <title>ShopSignal — Shopify intelligence</title>
    <link rel="stylesheet" href="<?= htmlspecialchars(shopSignalAssetUrl('styles.css')) ?>" />
  </head>
  <body>
    <div class="app-shell">
      <aside class="sidebar" id="sidebar">
        <div class="brand">
          <span class="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 32 32">
              <path d="M8.2 9.4 16 4l7.8 5.4v12.9L16 28l-7.8-5.7V9.4Z" />
              <path d="m11.8 17.1 2.7 2.7 5.9-7" />
            </svg>
          </span>
          <span>ShopSignal</span>
        </div>

        <nav class="main-nav" aria-label="Main navigation">
          <p class="nav-label">Workspace</p>
          <button class="nav-item active" data-view="explorer">
            <span data-icon="search"></span>
            Store explorer
            <kbd>⌘ K</kbd>
          </button>
          <button class="nav-item" data-view="lists">
            <span data-icon="bookmark"></span>
            Saved lists
            <span class="nav-count">8</span>
          </button>
          <button class="nav-item" data-view="signals">
            <span data-icon="activity"></span>
            Signals
            <span class="status-dot"></span>
          </button>
          <button class="nav-item" data-view="market">
            <span data-icon="chart"></span>
            Market trends
          </button>

          <p class="nav-label nav-label-spaced">Data</p>
          <button class="nav-item" data-view="apps">
            <span data-icon="grid"></span>
            Apps & tech
          </button>
          <button class="nav-item" data-view="products">
            <span data-icon="box"></span>
            Products
          </button>
        </nav>

        <div class="sidebar-card">
          <div class="mini-chart" aria-hidden="true">
            <i style="height: 32%"></i><i style="height: 46%"></i><i style="height: 38%"></i>
            <i style="height: 64%"></i><i style="height: 56%"></i><i style="height: 82%"></i>
            <i style="height: 100%"></i>
          </div>
          <p>Weekly data refresh</p>
          <span><?= number_format((int) $shopSignalData['stats']['updated_stores']) ?> stores updated</span>
        </div>

        <div class="user-block">
          <div class="avatar">AM</div>
          <div>
            <strong>Alex Morgan</strong>
            <span>Growth workspace</span>
          </div>
          <button class="icon-button" aria-label="Open profile menu" data-icon="more"></button>
        </div>
      </aside>

      <main class="main">
        <header class="topbar">
          <button class="icon-button mobile-menu" id="menuButton" aria-label="Toggle menu" data-icon="menu"></button>
          <div class="breadcrumb"><span>Workspace</span><b>/</b> Store explorer</div>
          <div class="top-actions">
            <button class="search-trigger" id="searchTrigger">
              <span data-icon="search"></span>
              <span>Search a store or domain</span>
              <kbd>⌘ K</kbd>
            </button>
            <button class="icon-button notification" aria-label="Notifications" data-icon="bell">
              <i></i>
            </button>
            <button class="button secondary" id="exportButton">
              <span data-icon="download"></span> Export
            </button>
          </div>
        </header>

        <section class="content" id="explorerView">
          <div class="page-heading">
            <div>
              <div class="eyebrow"><span></span> Shopify intelligence</div>
              <h1>Find your next best customer.</h1>
              <p>Search and segment 4.8M+ active Shopify stores by growth, technology, products, and market signals.</p>
            </div>
            <button class="button primary" id="saveViewButton">
              <span data-icon="plus"></span> Save this view
            </button>
          </div>

          <div class="metric-grid">
            <article class="metric-card">
              <div class="metric-top">
                <span>Matching stores</span>
                <span class="metric-icon violet" data-icon="store"></span>
              </div>
              <strong id="matchCount"><?= number_format((int) $shopSignalData['stats']['matching_stores']) ?></strong>
              <p><b>+12.4%</b> from last month</p>
            </article>
            <article class="metric-card">
              <div class="metric-top">
                <span>New this week</span>
                <span class="metric-icon green" data-icon="spark"></span>
              </div>
              <strong><?= number_format((int) $shopSignalData['stats']['new_this_week']) ?></strong>
              <p><b>+8.2%</b> weekly growth</p>
            </article>
            <article class="metric-card">
              <div class="metric-top">
                <span>Median revenue</span>
                <span class="metric-icon amber" data-icon="dollar"></span>
              </div>
              <strong><?= htmlspecialchars((string) $shopSignalData['stats']['median_revenue']) ?></strong>
              <p>Estimated monthly GMV</p>
            </article>
            <article class="metric-card">
              <div class="metric-top">
                <span>High-growth stores</span>
                <span class="metric-icon blue" data-icon="trending"></span>
              </div>
              <strong><?= number_format((int) $shopSignalData['stats']['high_growth_stores']) ?></strong>
              <p><b>14.5%</b> of this segment</p>
            </article>
          </div>

          <section class="explorer-card">
            <div class="filter-bar">
              <div class="filter-search">
                <span data-icon="search"></span>
                <input id="storeSearch" type="search" placeholder="Search within results..." autocomplete="off" />
              </div>
              <div class="filter-actions">
                <button class="button secondary" id="filterButton">
                  <span data-icon="sliders"></span> Filters <span class="filter-badge">4</span>
                </button>
                <button class="button secondary" id="columnsButton">
                  <span data-icon="columns"></span> Columns
                </button>
              </div>
            </div>

            <div class="chips" id="chips">
              <button class="chip">Shopify Plus <span>×</span></button>
              <button class="chip">United States <span>×</span></button>
              <button class="chip">Revenue: $50k+ <span>×</span></button>
              <button class="chip">Growth: 10%+ <span>×</span></button>
              <button class="clear-button" id="clearFilters">Clear all</button>
            </div>

            <div class="results-header">
              <div>
                <strong id="resultsLabel"><?= number_format((int) $shopSignalData['stats']['matching_stores']) ?> stores</strong>
                <span><?= $databaseConnected ? 'Live database connection' : 'Using sample data' ?></span>
              </div>
              <label class="sort-control">
                Sort by
                <select id="sortSelect">
                  <option value="signal">Growth signal</option>
                  <option value="revenue">Est. revenue</option>
                  <option value="traffic">Monthly traffic</option>
                  <option value="newest">Newest first</option>
                </select>
              </label>
            </div>

            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th class="check-cell"><input type="checkbox" id="selectAll" aria-label="Select all stores" /></th>
                    <th>Store</th>
                    <th>Category</th>
                    <th>Est. monthly revenue</th>
                    <th>Traffic</th>
                    <th>Growth signal</th>
                    <th>Stack</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody id="storeTable"></tbody>
              </table>
              <div class="empty-state" id="emptyState">
                <span data-icon="search"></span>
                <h3>No stores found</h3>
                <p>Try a different store name, domain, or category.</p>
              </div>
            </div>

            <div class="table-footer">
              <p><span id="visibleCount"><?= count($shopSignalData['stores']) ?></span> of <?= number_format((int) $shopSignalData['stats']['matching_stores']) ?> stores</p>
              <div class="pagination">
                <button class="icon-button" aria-label="Previous page" data-icon="chevron-left" disabled></button>
                <button class="page active">1</button>
                <button class="page">2</button>
                <button class="page">3</button>
                <span>…</span>
                <button class="page">42</button>
                <button class="icon-button" aria-label="Next page" data-icon="chevron-right"></button>
              </div>
            </div>
          </section>
        </section>

        <section class="placeholder-view" id="placeholderView">
          <span class="placeholder-icon" data-icon="spark"></span>
          <p class="eyebrow">ShopSignal workspace</p>
          <h2 id="placeholderTitle">Saved lists</h2>
          <p>This area is ready for the next part of the product experience.</p>
          <button class="button primary" id="backToExplorer">Return to explorer</button>
        </section>
      </main>
    </div>

    <div class="drawer-backdrop" id="drawerBackdrop"></div>
    <aside class="filter-drawer" id="filterDrawer" aria-hidden="true">
      <div class="drawer-header">
        <div>
          <p class="eyebrow">Refine audience</p>
          <h2>Filters</h2>
        </div>
        <button class="icon-button" id="closeFilters" aria-label="Close filters" data-icon="close"></button>
      </div>
      <div class="drawer-body">
        <div class="filter-group">
          <label>Platform plan</label>
          <div class="option-grid">
            <button class="option active">Shopify Plus</button>
            <button class="option">Advanced</button>
            <button class="option">Shopify</button>
            <button class="option">Basic</button>
          </div>
        </div>
        <div class="filter-group">
          <label for="countrySelect">Headquarters</label>
          <select id="countrySelect">
            <option>United States</option>
            <option>Canada</option>
            <option>United Kingdom</option>
            <option>Australia</option>
          </select>
        </div>
        <div class="filter-group">
          <label>Estimated monthly revenue</label>
          <div class="range-row"><span>$50k</span><span>$2m+</span></div>
          <input type="range" min="1" max="100" value="58" />
        </div>
        <div class="filter-group">
          <label>Technologies</label>
          <div class="check-list">
            <label><input type="checkbox" checked /> Klaviyo <span>12,482</span></label>
            <label><input type="checkbox" checked /> Recharge <span>6,218</span></label>
            <label><input type="checkbox" /> Gorgias <span>4,105</span></label>
            <label><input type="checkbox" /> Yotpo <span>3,842</span></label>
          </div>
        </div>
      </div>
      <div class="drawer-footer">
        <button class="button secondary" id="resetDrawer">Reset</button>
        <button class="button primary" id="applyFilters">Show <?= number_format((int) $shopSignalData['stats']['matching_stores']) ?> stores</button>
      </div>
    </aside>

    <div class="modal-backdrop" id="searchModal">
      <div class="command-modal">
        <div class="command-input">
          <span data-icon="search"></span>
          <input id="globalSearch" placeholder="Search any Shopify store or domain..." />
          <kbd>ESC</kbd>
        </div>
        <div class="command-content">
          <p class="command-label">Suggested stores</p>
          <button class="command-result" data-search="Allbirds">
            <span class="store-logo logo-allbirds">A</span>
            <span><strong>Allbirds</strong><small>allbirds.com · Footwear</small></span>
            <span data-icon="arrow-up-right"></span>
          </button>
          <button class="command-result" data-search="Gymshark">
            <span class="store-logo logo-gymshark">G</span>
            <span><strong>Gymshark</strong><small>gymshark.com · Apparel</small></span>
            <span data-icon="arrow-up-right"></span>
          </button>
          <button class="command-result" data-search="Brooklinen">
            <span class="store-logo logo-brooklinen">B</span>
            <span><strong>Brooklinen</strong><small>brooklinen.com · Home</small></span>
            <span data-icon="arrow-up-right"></span>
          </button>
        </div>
        <div class="command-footer"><span><kbd>↑</kbd><kbd>↓</kbd> to navigate</span><span><kbd>↵</kbd> to open</span></div>
      </div>
    </div>

    <aside class="detail-panel" id="detailPanel" aria-hidden="true">
      <div class="detail-header">
        <button class="icon-button" id="closeDetail" aria-label="Close store detail" data-icon="close"></button>
      </div>
      <div id="detailContent"></div>
    </aside>
    <div class="detail-backdrop" id="detailBackdrop"></div>

    <div class="toast" id="toast">
      <span data-icon="check"></span>
      <div><strong id="toastTitle">View saved</strong><p id="toastMessage">You can find it in Saved lists.</p></div>
    </div>

    <script>
      window.SHOPSIGNAL_DATA = <?= json_encode(
        [
          'stores' => $shopSignalData['stores'],
          'profiles' => $shopSignalData['profiles'],
          'stats' => $shopSignalData['stats'],
          'source' => $shopSignalData['source'],
        ],
        JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES
      ) ?>;
      window.SHOPSIGNAL_CONFIG = {
        basePath: <?= json_encode(shopSignalBasePath(), JSON_HEX_TAG | JSON_HEX_AMP) ?>,
        apiUrl: <?= json_encode(shopSignalAssetUrl('api/stores.php'), JSON_HEX_TAG | JSON_HEX_AMP) ?>
      };
    </script>
    <script src="<?= htmlspecialchars(shopSignalAssetUrl('app.js')) ?>"></script>
  </body>
</html>
