const icons = {
  search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>',
  bookmark: '<svg viewBox="0 0 24 24"><path d="M6 4.8A1.8 1.8 0 0 1 7.8 3h8.4A1.8 1.8 0 0 1 18 4.8V21l-6-3.6L6 21V4.8Z"/></svg>',
  activity: '<svg viewBox="0 0 24 24"><path d="M3 12h4l2-7 4 14 2-7h6"/></svg>',
  chart: '<svg viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>',
  grid: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
  box: '<svg viewBox="0 0 24 24"><path d="m4 7 8-4 8 4-8 4-8-4Z"/><path d="m4 7 8 4v10l-8-4V7ZM20 7l-8 4v10l8-4V7Z"/></svg>',
  more: '<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg>',
  menu: '<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
  bell: '<svg viewBox="0 0 24 24"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4"/></svg>',
  download: '<svg viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4M4 19h16"/></svg>',
  plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  store: '<svg viewBox="0 0 24 24"><path d="m4 10 1.4-5h13.2l1.4 5M5 10v9h14v-9"/><path d="M9 19v-5h6v5M3 10h18"/></svg>',
  spark: '<svg viewBox="0 0 24 24"><path d="m12 3 1.4 4.1L17.5 8.5l-4.1 1.4L12 14l-1.4-4.1-4.1-1.4 4.1-1.4L12 3ZM19 15l.7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7L19 15Z"/></svg>',
  dollar: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M15 8.5c-.7-.6-1.7-1-3-1-1.7 0-3 1-3 2.3 0 3.4 6 1.4 6 4.4 0 1.3-1.3 2.3-3 2.3-1.3 0-2.5-.5-3.2-1.2M12 5v14"/></svg>',
  trending: '<svg viewBox="0 0 24 24"><path d="m3 17 6-6 4 4 7-8"/><path d="M15 7h5v5"/></svg>',
  sliders: '<svg viewBox="0 0 24 24"><path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/></svg>',
  columns: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16M15 4v16"/></svg>',
  "chevron-left": '<svg viewBox="0 0 24 24"><path d="m15 18-6-6 6-6"/></svg>',
  "chevron-right": '<svg viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"/></svg>',
  close: '<svg viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></svg>',
  "arrow-up-right": '<svg viewBox="0 0 24 24"><path d="M7 17 17 7M8 7h9v9"/></svg>',
  check: '<svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg>',
  external: '<svg viewBox="0 0 24 24"><path d="M14 5h5v5M19 5l-9 9"/><path d="M19 14v4a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h4"/></svg>'
};

document.querySelectorAll("[data-icon]").forEach((element) => {
  const name = element.dataset.icon;
  if (icons[name]) element.innerHTML = icons[name];
});

const sampleStores = [
  { name: "Allbirds", domain: "allbirds.com", category: "Footwear", revenue: 8200000, revenueLabel: "$8.2M", traffic: 2400000, trafficLabel: "2.4M", growth: 28.4, signal: "High", logo: "A", logoClass: "logo-allbirds", stack: ["kl", "go", "yo"], founded: "2016", products: "278" },
  { name: "Gymshark", domain: "gymshark.com", category: "Apparel", revenue: 12900000, revenueLabel: "$12.9M", traffic: 5100000, trafficLabel: "5.1M", growth: 23.1, signal: "High", logo: "G", logoClass: "logo-gymshark", stack: ["kl", "rc", "go", "+3"], founded: "2012", products: "1,842" },
  { name: "Brooklinen", domain: "brooklinen.com", category: "Home & Living", revenue: 4800000, revenueLabel: "$4.8M", traffic: 890000, trafficLabel: "890K", growth: 18.6, signal: "High", logo: "B", logoClass: "logo-brooklinen", stack: ["kl", "go", "ok"], founded: "2014", products: "412" },
  { name: "Glossier", domain: "glossier.com", category: "Beauty", revenue: 7100000, revenueLabel: "$7.1M", traffic: 1800000, trafficLabel: "1.8M", growth: 15.2, signal: "High", logo: "G", logoClass: "logo-glossier", stack: ["kl", "yo", "+2"], founded: "2014", products: "186" },
  { name: "Beardbrand", domain: "beardbrand.com", category: "Personal Care", revenue: 910000, revenueLabel: "$910K", traffic: 340000, trafficLabel: "340K", growth: 9.8, signal: "Medium", logo: "B", logoClass: "logo-beardbrand", stack: ["kl", "rc", "go"], founded: "2012", products: "94" },
  { name: "Kylie Cosmetics", domain: "kyliecosmetics.com", category: "Beauty", revenue: 3600000, revenueLabel: "$3.6M", traffic: 1200000, trafficLabel: "1.2M", growth: 8.3, signal: "Medium", logo: "K", logoClass: "logo-kylie", stack: ["kl", "yo", "+4"], founded: "2015", products: "324" }
];

const sampleStoreProfiles = {
  "Allbirds": {
    location: "San Francisco, CA", country: "United States", employees: "350–500",
    email: "help@allbirds.com", phone: "+1 888 963 8944", language: "English", currency: "USD",
    avgPrice: "$86", orders: "94.3k", conversion: "3.1%", social: "1.2M",
    instagram: "482k", tiktok: "211k", facebook: "530k",
    apps: [["Klaviyo", "Email marketing", "May 2021"], ["Yotpo", "Reviews & loyalty", "Sep 2020"], ["Gorgias", "Customer support", "Jan 2022"], ["Nosto", "Personalization", "Mar 2023"]],
    products: [["Tree Runner", "Footwear", "$98"], ["Wool Runner", "Footwear", "$110"], ["Tree Dasher 2", "Footwear", "$135"]],
    signals: [["2 days ago", "Traffic spike", "Organic traffic increased 18% week over week."], ["8 days ago", "New app detected", "Nosto personalization was added to the storefront."], ["21 days ago", "Catalog growth", "34 new products were published."]]
  },
  "Gymshark": {
    location: "Solihull, England", country: "United Kingdom", employees: "900–1,000",
    email: "support@gymshark.com", phone: "+44 121 728 2828", language: "English", currency: "USD / GBP",
    avgPrice: "$54", orders: "238k", conversion: "3.7%", social: "12.8M",
    instagram: "7.1M", tiktok: "5.4M", facebook: "1.9M",
    apps: [["Klaviyo", "Email marketing", "Feb 2020"], ["Recharge", "Subscriptions", "Jun 2022"], ["Gorgias", "Customer support", "Oct 2021"], ["Algolia", "Site search", "Apr 2023"]],
    products: [["Arrival 5” Shorts", "Menswear", "$30"], ["Vital Seamless Leggings", "Womenswear", "$60"], ["Crest Hoodie", "Menswear", "$50"]],
    signals: [["Yesterday", "Paid media growth", "Estimated ad spend rose 24% in the last 30 days."], ["6 days ago", "International expansion", "New localized storefront detected for South Korea."], ["14 days ago", "Hiring signal", "12 new ecommerce roles were posted."]]
  },
  "Brooklinen": {
    location: "Brooklyn, NY", country: "United States", employees: "150–250",
    email: "hello@brooklinen.com", phone: "+1 646 798 7447", language: "English", currency: "USD",
    avgPrice: "$118", orders: "40.7k", conversion: "2.8%", social: "704k",
    instagram: "414k", tiktok: "83k", facebook: "207k",
    apps: [["Klaviyo", "Email marketing", "Aug 2019"], ["Okendo", "Reviews", "Nov 2021"], ["Gorgias", "Customer support", "Apr 2020"], ["Rebuy", "Upsells", "Jul 2023"]],
    products: [["Luxe Core Sheet Set", "Bedding", "$189"], ["Super-Plush Bath Towels", "Bath", "$89"], ["Down Comforter", "Bedding", "$299"]],
    signals: [["3 days ago", "Best-seller velocity", "Top bedding products gained 16% in review velocity."], ["11 days ago", "New technology", "Rebuy was added for post-purchase offers."], ["26 days ago", "Promotion detected", "A sitewide seasonal campaign went live."]]
  },
  "Glossier": {
    location: "New York, NY", country: "United States", employees: "200–350",
    email: "gteam@glossier.com", phone: "+1 855 929 2179", language: "English", currency: "USD",
    avgPrice: "$31", orders: "229k", conversion: "4.2%", social: "4.1M",
    instagram: "3.1M", tiktok: "840k", facebook: "172k",
    apps: [["Klaviyo", "Email marketing", "Mar 2020"], ["Yotpo", "Reviews & loyalty", "Jul 2021"], ["Nosto", "Personalization", "Feb 2022"], ["Loop Returns", "Returns", "Sep 2022"]],
    products: [["Boy Brow", "Makeup", "$18"], ["Glossier You", "Fragrance", "$78"], ["Cloud Paint", "Makeup", "$22"]],
    signals: [["Today", "Product launch", "A new Cloud Paint shade collection was published."], ["5 days ago", "Traffic acceleration", "Direct traffic increased 22% month over month."], ["18 days ago", "Technology change", "Checkout personalization scripts were updated."]]
  },
  "Beardbrand": {
    location: "Austin, TX", country: "United States", employees: "20–50",
    email: "support@beardbrand.com", phone: "+1 844 662 3273", language: "English", currency: "USD",
    avgPrice: "$38", orders: "24.1k", conversion: "2.6%", social: "2.3M",
    instagram: "190k", tiktok: "94k", facebook: "145k",
    apps: [["Klaviyo", "Email marketing", "Jun 2018"], ["Recharge", "Subscriptions", "Jan 2020"], ["Gorgias", "Customer support", "Aug 2021"], ["Stamped", "Reviews", "May 2019"]],
    products: [["Utility Beard Oil", "Grooming", "$36"], ["Sea Salt Spray", "Hair", "$22"], ["Utility Balm", "Grooming", "$42"]],
    signals: [["4 days ago", "Subscription growth", "Subscription messaging became more prominent onsite."], ["15 days ago", "Catalog update", "Six product bundles were refreshed."], ["29 days ago", "Email activity", "Campaign frequency increased by 13%."]]
  },
  "Kylie Cosmetics": {
    location: "Los Angeles, CA", country: "United States", employees: "100–200",
    email: "customerservice@kyliecosmetics.com", phone: "+1 833 545 9543", language: "English", currency: "USD",
    avgPrice: "$29", orders: "124k", conversion: "3.4%", social: "31.2M",
    instagram: "25.7M", tiktok: "3.8M", facebook: "1.7M",
    apps: [["Klaviyo", "Email marketing", "Nov 2020"], ["Yotpo", "Reviews & loyalty", "Feb 2021"], ["Gorgias", "Customer support", "Aug 2022"], ["Afterpay", "Payments", "Jun 2020"]],
    products: [["Lip Kit", "Makeup", "$35"], ["Kylash Mascara", "Makeup", "$24"], ["Cosmic Eau de Parfum", "Fragrance", "$48"]],
    signals: [["Yesterday", "Social momentum", "TikTok mentions increased 31% this week."], ["9 days ago", "Product launch", "A limited lip collection was added."], ["23 days ago", "Promotional change", "Free shipping threshold decreased."]]
  }
};

const stores = Array.isArray(window.SHOPSIGNAL_DATA?.stores) && window.SHOPSIGNAL_DATA.stores.length
  ? window.SHOPSIGNAL_DATA.stores
  : sampleStores;
const storeProfiles = window.SHOPSIGNAL_DATA?.profiles && Object.keys(window.SHOPSIGNAL_DATA.profiles).length
  ? window.SHOPSIGNAL_DATA.profiles
  : sampleStoreProfiles;

const table = document.getElementById("storeTable");
const emptyState = document.getElementById("emptyState");
const visibleCount = document.getElementById("visibleCount");
let currentStores = [...stores];

function stackHtml(stack) {
  return stack.map((item) => {
    if (item.startsWith("+")) return `<span class="tech more-tech">${item}</span>`;
    const labels = { kl: "K", rc: "R", go: "G", yo: "Y", ok: "O" };
    return `<span class="tech ${item}">${labels[item] || item.charAt(0).toUpperCase()}</span>`;
  }).join("");
}

function renderStores(items) {
  table.innerHTML = items.map((store, index) => `
    <tr data-store="${store.name}">
      <td class="check-cell"><input type="checkbox" class="row-check" aria-label="Select ${store.name}" /></td>
      <td>
        <div class="store-cell">
          <span class="store-logo ${store.logoClass}">${store.logo}</span>
          <span class="store-meta"><strong>${store.name}</strong><span>${store.domain}</span></span>
        </div>
      </td>
      <td><span class="category-pill">${store.category}</span></td>
      <td class="revenue"><strong>${store.revenueLabel}</strong><span>Shopify Plus</span></td>
      <td class="traffic">${store.trafficLabel}</td>
      <td><span class="signal ${store.signal === "Medium" ? "medium" : ""}">↗ ${store.growth}%</span></td>
      <td><div class="tech-stack">${stackHtml(store.stack)}</div></td>
      <td><button class="icon-button row-action" aria-label="Open ${store.name} details" data-row="${index}">${icons.more}</button></td>
    </tr>
  `).join("");
  visibleCount.textContent = items.length;
  emptyState.style.display = items.length ? "none" : "block";
  table.closest("table").style.display = items.length ? "table" : "none";
}
renderStores(currentStores);

const searchInput = document.getElementById("storeSearch");
searchInput.addEventListener("input", () => {
  const query = searchInput.value.trim().toLowerCase();
  currentStores = stores.filter((store) =>
    [store.name, store.domain, store.category].some((value) => value.toLowerCase().includes(query))
  );
  renderStores(currentStores);
});

document.getElementById("sortSelect").addEventListener("change", (event) => {
  const type = event.target.value;
  currentStores.sort((a, b) => {
    if (type === "revenue") return b.revenue - a.revenue;
    if (type === "traffic") return b.traffic - a.traffic;
    if (type === "newest") return Number(b.founded) - Number(a.founded);
    return b.growth - a.growth;
  });
  renderStores(currentStores);
});

document.getElementById("selectAll").addEventListener("change", (event) => {
  document.querySelectorAll(".row-check").forEach((checkbox) => checkbox.checked = event.target.checked);
});

const chips = document.getElementById("chips");
chips.addEventListener("click", (event) => {
  const chip = event.target.closest(".chip");
  if (chip) {
    chip.remove();
    updateFilterBadge();
  }
});
function updateFilterBadge() {
  document.querySelector(".filter-badge").textContent = document.querySelectorAll(".chip").length;
}
document.getElementById("clearFilters").addEventListener("click", () => {
  document.querySelectorAll(".chip").forEach((chip) => chip.remove());
  updateFilterBadge();
  showToast("Filters cleared", "Showing the full Shopify store index.");
});

const filterDrawer = document.getElementById("filterDrawer");
const drawerBackdrop = document.getElementById("drawerBackdrop");
function setFilterDrawer(open) {
  filterDrawer.classList.toggle("open", open);
  drawerBackdrop.classList.toggle("open", open);
  filterDrawer.setAttribute("aria-hidden", String(!open));
}
document.getElementById("filterButton").addEventListener("click", () => setFilterDrawer(true));
document.getElementById("closeFilters").addEventListener("click", () => setFilterDrawer(false));
drawerBackdrop.addEventListener("click", () => setFilterDrawer(false));
document.getElementById("applyFilters").addEventListener("click", () => {
  setFilterDrawer(false);
  showToast("Filters applied", "Your Shopify audience has been refreshed.");
});
document.getElementById("resetDrawer").addEventListener("click", () => {
  document.querySelectorAll(".option").forEach((option, i) => option.classList.toggle("active", i === 0));
  document.querySelectorAll(".check-list input").forEach((input) => input.checked = false);
});
document.querySelectorAll(".option").forEach((option) => option.addEventListener("click", () => option.classList.toggle("active")));

const searchModal = document.getElementById("searchModal");
const globalSearch = document.getElementById("globalSearch");
function setSearchModal(open) {
  searchModal.classList.toggle("open", open);
  if (open) setTimeout(() => globalSearch.focus(), 80);
  else globalSearch.value = "";
}
document.getElementById("searchTrigger").addEventListener("click", () => setSearchModal(true));
searchModal.addEventListener("click", (event) => {
  if (event.target === searchModal) setSearchModal(false);
});
document.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    setSearchModal(true);
  }
  if (event.key === "Escape") {
    setSearchModal(false);
    setFilterDrawer(false);
    setDetailPanel(false);
  }
});
globalSearch.addEventListener("input", () => {
  const query = globalSearch.value.toLowerCase();
  document.querySelectorAll(".command-result").forEach((result) => {
    result.style.display = result.innerText.toLowerCase().includes(query) ? "flex" : "none";
  });
});
document.querySelectorAll(".command-result").forEach((result) => {
  result.addEventListener("click", () => {
    searchInput.value = result.dataset.search;
    searchInput.dispatchEvent(new Event("input"));
    setSearchModal(false);
    searchInput.scrollIntoView({ behavior: "smooth", block: "center" });
  });
});

const detailPanel = document.getElementById("detailPanel");
const detailBackdrop = document.getElementById("detailBackdrop");
function setDetailPanel(open, store) {
  detailPanel.classList.toggle("open", open);
  detailBackdrop.classList.toggle("open", open);
  detailPanel.setAttribute("aria-hidden", String(!open));
  if (open && store) {
    const profile = storeProfiles[store.name];
    document.getElementById("detailContent").innerHTML = `
      <div class="detail-body">
        <div class="detail-identity">
          <span class="store-logo ${store.logoClass}">${store.logo}</span>
          <div>
            <div class="detail-title-row"><h2>${store.name}</h2><span class="verified-badge">${icons.check} Verified</span></div>
            <p>${store.domain} · ${store.category}</p>
            <div class="detail-location">● Active store <span>·</span> ${profile.location}</div>
          </div>
        </div>
        <div class="detail-actions">
          <button class="button primary" data-detail-action="save">${icons.bookmark} Add to list</button>
          <button class="button secondary" data-detail-action="visit">${icons.external} Visit store</button>
        </div>

        <div class="detail-tabs" role="tablist">
          <button class="detail-tab active" data-detail-tab="overview">Overview</button>
          <button class="detail-tab" data-detail-tab="technology">Technology <span>${profile.apps.length}</span></button>
          <button class="detail-tab" data-detail-tab="products">Products</button>
          <button class="detail-tab" data-detail-tab="signals">Signals <i></i></button>
        </div>

        <div class="detail-tab-panel active" data-detail-panel="overview">
          <div class="detail-section detail-section-first">
            <div class="section-heading"><h3>Commerce performance</h3><span>Estimated</span></div>
            <div class="detail-stat-grid">
              <div class="detail-stat"><span>Monthly revenue</span><strong>${store.revenueLabel}</strong><small>↗ ${store.growth}% vs last month</small></div>
              <div class="detail-stat"><span>Monthly traffic</span><strong>${store.trafficLabel}</strong><small>Top 8% of Shopify</small></div>
              <div class="detail-stat"><span>Monthly orders</span><strong>${profile.orders}</strong><small>${profile.conversion} conversion</small></div>
              <div class="detail-stat"><span>Average price</span><strong>${profile.avgPrice}</strong><small>${store.products} products</small></div>
            </div>
          </div>

          <div class="detail-section">
            <div class="section-heading"><h3>Company profile</h3><span>Firmographics</span></div>
            <dl class="data-list">
              <div><dt>Headquarters</dt><dd>${profile.location}</dd></div>
              <div><dt>Country</dt><dd>${profile.country}</dd></div>
              <div><dt>Employees</dt><dd>${profile.employees}</dd></div>
              <div><dt>Founded</dt><dd>${store.founded}</dd></div>
              <div><dt>Store language</dt><dd>${profile.language}</dd></div>
              <div><dt>Currency</dt><dd>${profile.currency}</dd></div>
            </dl>
          </div>

          <div class="detail-section">
            <div class="section-heading"><h3>Contact information</h3><span>Public data</span></div>
            <div class="contact-card">
              <div><span>Email</span><strong>${profile.email}</strong></div>
              <button class="copy-button" data-copy="${profile.email}">Copy</button>
              <div><span>Phone</span><strong>${profile.phone}</strong></div>
              <button class="copy-button" data-copy="${profile.phone}">Copy</button>
            </div>
          </div>

          <div class="detail-section">
            <div class="section-heading"><h3>Social audience</h3><strong>${profile.social} total</strong></div>
            <div class="social-grid">
              <div><span>Instagram</span><strong>${profile.instagram}</strong></div>
              <div><span>TikTok</span><strong>${profile.tiktok}</strong></div>
              <div><span>Facebook</span><strong>${profile.facebook}</strong></div>
            </div>
          </div>
        </div>

        <div class="detail-tab-panel" data-detail-panel="technology">
          <div class="detail-section detail-section-first">
            <div class="section-heading"><h3>Detected technology</h3><span>Updated today</span></div>
            <div class="technology-list">
              <div class="technology-row platform-row"><span class="app-icon shopify-icon">S</span><div><strong>Shopify Plus</strong><small>Ecommerce platform</small></div><span class="tech-date">Since ${store.founded}</span></div>
              ${profile.apps.map(([name, category, date], index) => `
                <div class="technology-row">
                  <span class="app-icon app-color-${index + 1}">${name.charAt(0)}</span>
                  <div><strong>${name}</strong><small>${category}</small></div>
                  <span class="tech-date">${date}</span>
                </div>`).join("")}
            </div>
          </div>
          <div class="detail-section">
            <h3>Technology spend</h3>
            <div class="spend-card"><span>Estimated app spend</span><strong>$1,240 / month</strong><div><i style="width:72%"></i></div><small>Higher than 72% of similar stores</small></div>
          </div>
        </div>

        <div class="detail-tab-panel" data-detail-panel="products">
          <div class="detail-section detail-section-first">
            <div class="section-heading"><h3>Top products</h3><span>${store.products} detected</span></div>
            <div class="product-list">
              ${profile.products.map(([name, category, price], index) => `
                <div class="product-row">
                  <span class="product-thumb product-${index + 1}">${name.charAt(0)}</span>
                  <div><strong>${name}</strong><small>${category}</small></div>
                  <strong>${price}</strong>
                </div>`).join("")}
            </div>
          </div>
          <div class="detail-section">
            <h3>Catalog insights</h3>
            <dl class="data-list">
              <div><dt>Total products</dt><dd>${store.products}</dd></div>
              <div><dt>Average price</dt><dd>${profile.avgPrice}</dd></div>
              <div><dt>Products added (30d)</dt><dd>34</dd></div>
              <div><dt>Products on sale</dt><dd>12%</dd></div>
            </dl>
          </div>
        </div>

        <div class="detail-tab-panel" data-detail-panel="signals">
          <div class="detail-section detail-section-first">
            <div class="section-heading"><h3>Recent buying signals</h3><span>Last 30 days</span></div>
            <div class="signal-note">ShopSignal score: <strong>High intent</strong>. This store is growing and actively investing in its ecommerce stack.</div>
            <div class="signal-timeline">
              ${profile.signals.map(([date, title, description]) => `
                <div class="timeline-item">
                  <span></span>
                  <div><small>${date}</small><strong>${title}</strong><p>${description}</p></div>
                </div>`).join("")}
            </div>
          </div>
        </div>
      </div>`;
  }
}
table.addEventListener("click", (event) => {
  if (event.target.closest("input")) return;
  const row = event.target.closest("tr");
  if (!row) return;
  const store = stores.find((item) => item.name === row.dataset.store);
  setDetailPanel(true, store);
});
document.getElementById("closeDetail").addEventListener("click", () => setDetailPanel(false));
detailBackdrop.addEventListener("click", () => setDetailPanel(false));
detailPanel.addEventListener("click", async (event) => {
  const tab = event.target.closest("[data-detail-tab]");
  if (tab) {
    const selected = tab.dataset.detailTab;
    detailPanel.querySelectorAll("[data-detail-tab]").forEach((item) => item.classList.toggle("active", item === tab));
    detailPanel.querySelectorAll("[data-detail-panel]").forEach((panel) => panel.classList.toggle("active", panel.dataset.detailPanel === selected));
    return;
  }

  const copyButton = event.target.closest("[data-copy]");
  if (copyButton) {
    try {
      await navigator.clipboard.writeText(copyButton.dataset.copy);
      copyButton.textContent = "Copied";
      setTimeout(() => copyButton.textContent = "Copy", 1400);
    } catch {
      showToast("Copy unavailable", copyButton.dataset.copy);
    }
    return;
  }

  const action = event.target.closest("[data-detail-action]");
  if (action?.dataset.detailAction === "save") showToast("Store added", "The store is now in your prospect list.");
  if (action?.dataset.detailAction === "visit") showToast("Store link ready", "External navigation is disabled in this mockup.");
});

let toastTimer;
function showToast(title, message) {
  document.getElementById("toastTitle").textContent = title;
  document.getElementById("toastMessage").textContent = message;
  const toast = document.getElementById("toast");
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2700);
}
document.getElementById("saveViewButton").addEventListener("click", () => showToast("View saved", "You can find it in Saved lists."));
document.getElementById("exportButton").addEventListener("click", () => {
  const count = Number(window.SHOPSIGNAL_DATA?.stats?.matching_stores || stores.length).toLocaleString();
  showToast("Export prepared", `A CSV with ${count} stores is ready.`);
});
document.getElementById("columnsButton").addEventListener("click", () => showToast("Columns are customizable", "Drag, hide, and reorder fields in the full product."));

const explorerView = document.getElementById("explorerView");
const placeholderView = document.getElementById("placeholderView");
const placeholderTitle = document.getElementById("placeholderTitle");
document.querySelectorAll(".nav-item").forEach((item) => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((nav) => nav.classList.remove("active"));
    item.classList.add("active");
    const isExplorer = item.dataset.view === "explorer";
    explorerView.style.display = isExplorer ? "block" : "none";
    placeholderView.classList.toggle("show", !isExplorer);
    placeholderTitle.textContent = item.textContent.replace("⌘ K", "").replace(/[0-9]/g, "").trim();
    document.getElementById("sidebar").classList.remove("open");
  });
});
document.getElementById("backToExplorer").addEventListener("click", () => document.querySelector('[data-view="explorer"]').click());
document.getElementById("menuButton").addEventListener("click", () => document.getElementById("sidebar").classList.toggle("open"));

document.querySelectorAll(".page").forEach((page) => {
  page.addEventListener("click", () => {
    document.querySelectorAll(".page").forEach((item) => item.classList.remove("active"));
    page.classList.add("active");
    showToast(`Page ${page.textContent}`, "Loaded a fresh set of matching stores.");
  });
});
