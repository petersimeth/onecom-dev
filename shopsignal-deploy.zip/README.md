# ShopSignal PHP prototype

The dashboard is now served by `index.php`. It uses PDO and automatically reads
store data from a database when `DB_DSN` is configured. Without credentials it
continues to use the frontend sample data.

## Run locally

```bash
php -S 127.0.0.1:4173
```

Open `http://127.0.0.1:4173/index.php`.

## Connect MySQL

1. Create a database and run `database/schema.sql`.
2. Configure the environment:

```bash
export DB_DSN="mysql:host=127.0.0.1;port=3306;dbname=shopsignal;charset=utf8mb4"
export DB_USER="shopsignal"
export DB_PASSWORD="your-password"
php -S 127.0.0.1:4173
```

The page and `api/stores.php` will then use database rows automatically.

## Deploy in a onecom.io subfolder

The project is subfolder-safe. A suggested test URL is:

```text
https://onecom.io/shopsignal/
```

Upload the project files into the matching public web directory, for example:

```text
public_html/shopsignal/
```

The deployed folder should contain:

```text
shopsignal/
├── .htaccess
├── api/
├── database/
├── src/
├── app.js
├── index.php
└── styles.css
```

For a database connection on shared hosting:

1. Create a MySQL database in the hosting control panel.
2. Import `database/schema.sql`.
3. Import `database/seed.sql` to load the six dashboard stores.
4. Copy `config.example.php` to `config.local.php`.
5. Enter the host-provided database name, username, and password.

`config.local.php` is intentionally excluded from Git and blocked from web
access by `.htaccess`.

The application derives its base path from the current request, so assets and
the API work at `/shopsignal/`, `/store-data/`, or another subfolder without
source changes.

## Verify MySQL

After configuring the database, open:

```text
https://onecom.io/shopsignal/api/status.php
```

A successful response looks like:

```json
{"connected":true,"driver":"mysql","database":"shopsignal","stores":6}
```

The dashboard header will also change from `Using sample data` to
`Live database connection`.

If the status endpoint reports a failed connection, temporarily set:

```php
'db_debug' => true,
```

in `config.local.php`, reload `api/status.php`, and inspect the `diagnostic`
field. Turn debugging off again after fixing the connection.

Common shared-hosting causes:

- The database host is not `localhost`; use the hostname shown in the panel.
- The provider prefixes database and user names, such as `account_shopsignal`.
- The MySQL user has not been assigned to the database.
- The user is assigned but lacks `SELECT`, `INSERT`, `UPDATE`, and `DELETE`.
- The password contains a typo or was changed after creating the config file.
- `schema.sql` has not been imported into the database named in the DSN.
